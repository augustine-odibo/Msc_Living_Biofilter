# Full analysis pipeline for the living-biofilter study (R version).
#
#   Rscript R/run_analysis.R                     # example data
#   Rscript R/run_analysis.R data/raw            # your raw data
#   Rscript R/run_analysis.R data/raw --paper-methods
#
# Outputs (tables, statistics report, figures) go to results/R/.

suppressPackageStartupMessages({
  library(dplyr); library(tidyr); library(readr)
})

get_script_dir <- function() {
  arg <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(arg)) dirname(normalizePath(sub("^--file=", "", arg))) else getwd()
}
R_DIR <- get_script_dir()
ROOT <- normalizePath(file.path(R_DIR, ".."))
source(file.path(R_DIR, "equations.R"))
source(file.path(R_DIR, "stats.R"))
source(file.path(R_DIR, "plots.R"))

args <- commandArgs(trailingOnly = TRUE)
paper_methods <- "--paper-methods" %in% args
args <- setdiff(args, "--paper-methods")
DATA <- if (length(args) >= 1) args[1] else file.path(ROOT, "data", "example")
OUT  <- if (length(args) >= 2) args[2] else file.path(ROOT, "results", "R")
FIG  <- file.path(OUT, "figures")
dir.create(FIG, recursive = TRUE, showWarnings = FALSE)

TREATMENTS <- c("Control", "Chemical fertilizer", "Biofilter (CV/BS 3:1)",
                "Biofilter (CV/BS 1:1)", "Biofilter control")
CO_RATIOS <- c("3:1", "1:1", "1:3")
PAPER_METHOD <- c("Morning glory" = "anova", "Sunflower" = "kruskal", "Cucumber" = "kruskal")

report <- character()
logp <- function(...) { txt <- paste0(...); cat(txt, "\n"); report <<- c(report, txt) }
logo <- function(x) logp(paste(capture.output(print(x)), collapse = "\n"))
rule <- function(title) logp(strrep("=", 70), "\n", title, "\n", strrep("=", 70))
rd <- function(f) read_csv(file.path(DATA, f), show_col_types = FALSE)

# ---------------------------------------------------------- 3.1 toxicity
tox <- rd("toxicity.csv") %>%
  mutate(viability_pct = cell_viability(sample_od_d0, sample_od_d7, control_od_d0,
                                        control_od_d7, blank_d0, blank_d7))
write_csv(tox, file.path(OUT, "toxicity_processed.csv"))
rule("3.1 CELL VIABILITY (toxicity test)")
logo(factorial_anova(tox, viability_pct ~ binder * inoculum))
tox_letters <- list()
for (b in unique(tox$binder)) {
  res <- compare_groups(filter(tox, binder == b, inoculum %in% CO_RATIOS), "viability_pct", "inoculum")
  tox_letters[[b]] <- res$letters
  logp(format_result(paste0("Viability, ", b, " binder, mixing ratios"), res))
}

# ------------------------------------------------------- 3.2 degradation
deg <- rd("degradation.csv") %>%
  mutate(degradation_pct = degradation(dry_weight_d0, dry_weight_d7),
         degradation_asin = arcsine_transform(degradation_pct))
write_csv(deg, file.path(OUT, "degradation_processed.csv"))
rule("3.2 DEGRADATION OF LIVING BIOFILTERS")
logo(factorial_anova(deg, degradation_asin ~ binder * inoculum))
deg_letters <- list()
for (b in unique(deg$binder)) {
  res <- compare_groups(filter(deg, binder == b, inoculum %in% CO_RATIOS), "degradation_pct",
                        "inoculum", transform = "arcsine")
  deg_letters[[b]] <- res$letters
  logp(format_result(paste0("Degradation, ", b, " binder, mixing ratios"), res))
}

# ------------------------------------------------------- decision matrix
dm <- inner_join(
  tox %>% group_by(binder, inoculum) %>% summarise(viability_pct = mean(viability_pct), .groups = "drop"),
  deg %>% group_by(binder, inoculum) %>% summarise(degradation_pct = mean(degradation_pct), .groups = "drop"),
  by = c("binder", "inoculum")) %>%
  filter(inoculum %in% CO_RATIOS) %>%
  mutate(score = decision_matrix(viability_pct, degradation_pct)) %>%
  arrange(desc(score))
write_csv(dm, file.path(OUT, "decision_matrix.csv"))
logp("Decision matrix (higher score = better binder/ratio):")
logo(as.data.frame(dm))

add_letters <- function(summ, lt) {
  summ$letter <- mapply(function(b, i) { x <- lt[[b]][i]; if (is.null(x) || is.na(x)) "" else x },
                        summ$binder, summ$inoculum)
  summ
}
tox_sum <- tox %>% group_by(binder, inoculum) %>%
  summarise(mean = mean(viability_pct), sd = sd(viability_pct), .groups = "drop") %>%
  add_letters(tox_letters)
fig_binder_screen(tox_sum, "% Cell viability", file.path(FIG, "fig2ab_cell_viability.png"))
deg_sum <- deg %>% group_by(binder, inoculum) %>%
  summarise(mean = mean(degradation_pct), sd = sd(degradation_pct), .groups = "drop") %>%
  add_letters(deg_letters)
fig_binder_screen(deg_sum, "% Degradation", file.path(FIG, "fig2ef_degradation.png"))

# --------------------------------------------------------- 3.3 nutrients
nut <- rd("nutrients.csv")
init <- nut %>% filter(day == 0) %>%
  select(ratio, system, replicate, nh4_initial = nh4_mg_l, po4_initial = po4_mg_l)
nut <- nut %>% left_join(init, by = c("ratio", "system", "replicate")) %>%
  mutate(nh4_removal_pct = removal_efficiency(nh4_initial, nh4_mg_l),
         po4_removal_pct = removal_efficiency(po4_initial, po4_mg_l),
         nh4_rate = absorption_rate(nh4_initial, nh4_mg_l, volume_l, day, initial_biomass_g),
         po4_rate = absorption_rate(po4_initial, po4_mg_l, volume_l, day, initial_biomass_g),
         group = paste0(ratio, "_CV/BS_", system),
         subject = paste0(group, "_r", replicate))
write_csv(nut, file.path(OUT, "nutrients_processed.csv"))
nut_sum <- nut %>% group_by(ratio, system, day) %>%
  summarise(across(c(nh4_removal_pct, po4_removal_pct, nh4_rate, po4_rate),
                   list(mean = mean, sd = sd)), .groups = "drop")
write_csv(nut_sum, file.path(OUT, "nutrients_summary.csv"))

rule("3.3 NUTRIENT REMOVAL")
last <- filter(nut, day == max(day))
for (n in c("nh4", "po4")) {
  col <- paste0(n, "_removal_pct")
  logp(sprintf("Day %d %s removal (mean +/- SD):", max(nut$day), toupper(n)))
  logo(as.data.frame(last %>% group_by(group) %>%
                       summarise(mean = mean(.data[[col]]), sd = sd(.data[[col]]))))
  logp(format_result(paste0(toupper(n), " removal on final day"),
                     compare_groups(last, col, "group", method = "kruskal")))
  rm <- nut %>% filter(day > 0) %>% mutate(asin = arcsine_transform(.data[[col]]))
  logp("Two-way repeated-measures (mixed) ANOVA, ", toupper(n), " removal (arcsine):")
  logo(mixed_anova(rm, "asin", "day", "group", "subject"))
}
fig_nutrients(nut_sum, file.path(FIG, "fig3_nutrient_removal.png"))

# ------------------------------------------------ 3.4-3.8 plants and soil
soil <- rd("soil.csv") %>%
  mutate(total_n_mg_kg = total_n(n_titrant_volume, n_acid_normality, soil_weight_kg),
         total_p_mg_kg = total_p(p_conc_mg_ml, p_v_sample, p_acid_molarity, p_v_naoh,
                                 p_v_molybdate, p_dilution_pct, soil_weight_kg),
         total_k_mg_kg = total_k(k_od, soil_weight_kg))
pl <- rd("plants.csv") %>%
  mutate(chl_a_ug_g = chlorophyll_a(A630, A645, A663, A750, dry_biomass_g)) %>%
  left_join(select(soil, plant, treatment, replicate, soil_ph,
                   total_n_mg_kg, total_p_mg_kg, total_k_mg_kg),
            by = c("plant", "treatment", "replicate"))
write_csv(pl, file.path(OUT, "plants_processed.csv"))

variables <- c(total_height_cm = "Total plant height (cm)", leaf_cm = "Leaf (cm)",
               branch_cm = "Branch (cm)", stem_cm = "Stem (cm)", root_cm = "Root (cm)",
               dry_biomass_g = "Dry biomass (g)", soil_ph = "Soil pH",
               chl_a_ug_g = "Chl a (ug/g plant biomass)", total_n_mg_kg = "Soil total N (mg/kg)",
               total_p_mg_kg = "Soil total P (mg/kg)", total_k_mg_kg = "Soil total K (mg/kg)")

rule("3.4-3.8 PLANT GROWTH, SOIL pH, CHLOROPHYLL a, SOIL N/P/K")
pl_long <- pl %>% pivot_longer(all_of(names(variables)), names_to = "variable")
pl_sum <- pl_long %>% group_by(plant, treatment, variable) %>%
  summarise(mean = mean(value, na.rm = TRUE), sd = sd(value, na.rm = TRUE), .groups = "drop") %>%
  mutate(letter = "")
stat_rows <- list()
for (plant_i in unique(pl$plant)) {
  method <- if (paper_methods) PAPER_METHOD[[plant_i]] else "auto"
  for (v in names(variables)) {
    g <- filter(pl, plant == plant_i)
    res <- compare_groups(g, v, "treatment", method = method)
    logp(format_result(paste0(plant_i, " - ", variables[[v]]), res))
    idx <- pl_sum$plant == plant_i & pl_sum$variable == v
    pl_sum$letter[idx] <- res$letters[pl_sum$treatment[idx]]
    stat_rows[[length(stat_rows) + 1]] <- data.frame(
      plant = plant_i, variable = v, test = res$test, statistic = res$statistic,
      df = paste(res$df, collapse = ","), p = res$p, t(res$letters), check.names = FALSE)
  }
}
write_csv(pl_sum, file.path(OUT, "plants_summary.csv"))
write_csv(bind_rows(stat_rows), file.path(OUT, "plants_statistics.csv"))

fig_plant_lengths(pl_sum, TREATMENTS, file.path(FIG, "fig4_plant_lengths.png"))
fig_grid(pl_sum, c(dry_biomass_g = "Biomass (g)", soil_ph = "pH values",
                   chl_a_ug_g = "Chl a per weight of biomass (ug/g)"),
         TREATMENTS, file.path(FIG, "fig5_biomass_ph_chla.png"))
fig_grid(pl_sum, c(total_n_mg_kg = "Total N (mg/kg soil)", total_p_mg_kg = "Total P (mg/kg soil)",
                   total_k_mg_kg = "Total K (mg/kg soil)"),
         TREATMENTS, file.path(FIG, "fig6_soil_npk.png"))

writeLines(report, file.path(OUT, "statistics_report.txt"))
cat("\nDone. Results in", OUT, "\n")
