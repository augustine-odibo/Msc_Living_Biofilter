# Equations from Odibo et al. (2024), Bioresource Technology 398, 130509.
# https://doi.org/10.1016/j.biortech.2024.130509
# All functions are vectorised and can be used inside dplyr::mutate().

# 2.3 Toxicity test - % cell viability (adapted from He et al., 2006)
cell_viability <- function(sample_od_d0, sample_od_d7, control_od_d0, control_od_d7,
                           blank_d0 = 0, blank_d7 = 0) {
  sample_growth  <- (sample_od_d7 - blank_d7) - (sample_od_d0 - blank_d0)
  control_growth <- (control_od_d7 - blank_d7) - (control_od_d0 - blank_d0)
  sample_growth / control_growth * 100
}

# 2.4 % degradation = (W0 - W7) / W0 x 100
degradation <- function(dry_weight_d0, dry_weight_d7) {
  (dry_weight_d0 - dry_weight_d7) / dry_weight_d0 * 100
}

# 2.5 % nutrient removal efficiency = (Ci - Cf) / Ci x 100
removal_efficiency <- function(c_initial, c_final) {
  (c_initial - c_final) / c_initial * 100
}

# 2.5 Nutrient absorption rate (mg day^-1 g_biomass^-1) = (Ci - Cf) x V / (T x m)
absorption_rate <- function(c_initial, c_final, volume_l, time_day, biomass_g) {
  ifelse(time_day > 0, (c_initial - c_final) * volume_l / (time_day * biomass_g), NA_real_)
}

# 2.10 Chl a per dried plant biomass (ug/g)
# [11.62(A663-A750) - 2.16(A645-A750) - 0.1(A630-A750)] / dry weight
# extract_volume_ml = 1 reproduces the paper; pass the real extract volume
# (e.g. 1.5 mL) to get ug chlorophyll per g biomass.
chlorophyll_a <- function(a630, a645, a663, a750, dry_weight_g, extract_volume_ml = 1) {
  conc <- 11.62 * (a663 - a750) - 2.16 * (a645 - a750) - 0.10 * (a630 - a750)
  conc * extract_volume_ml / dry_weight_g
}

# 2.12.1 Kjeldahl total N (mg/kg) = V x N x 14.01 x 100 / W
total_n <- function(titrant_volume, acid_normality, soil_weight_kg) {
  titrant_volume * acid_normality * 14.01 * 100 / soil_weight_kg
}

# 2.12.2 Total P (mg/kg) = C x (V1/M) x (V2/V3) x 1000 / ((100 - H) x W)
total_p <- function(p_conc_mg_ml, v_sample, acid_molarity, v_naoh, v_molybdate,
                    dilution_pct, soil_weight_kg) {
  p_conc_mg_ml * (v_sample / acid_molarity) * (v_naoh / v_molybdate) * 1000 /
    ((100 - dilution_pct) * soil_weight_kg)
}

# 2.12.3 Total K (mg/kg) = OD x 1.2 x 100 / W
total_k <- function(od_k, soil_weight_kg, standard_conc = 100) {
  od_k * 1.2 * standard_conc / soil_weight_kg
}

# 2.13 arcsine transform for % data (clipped to 0-100 %, viability can exceed 100 %)
arcsine_transform <- function(percent) {
  asin(sqrt(pmin(pmax(percent / 100, 0), 1)))
}

# 2.4 Decision matrix: high viability and low degradation are both good.
# Each criterion min-max scaled to 0-1, then weighted. Higher score = better.
decision_matrix <- function(viability, degradation_pct, w_viability = 0.5, w_degradation = 0.5) {
  scale01 <- function(x) if (diff(range(x)) == 0) x * 0 else (x - min(x)) / diff(range(x))
  w_viability * scale01(viability) + w_degradation * (1 - scale01(degradation_pct))
}
