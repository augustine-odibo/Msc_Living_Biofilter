# Checks the equations against values reported in Odibo et al. (2024).
#   Rscript R/tests/test_equations.R
arg <- grep("^--file=", commandArgs(FALSE), value = TRUE)
here <- if (length(arg)) dirname(normalizePath(sub("^--file=", "", arg))) else "R/tests"
source(file.path(here, "..", "equations.R"))
source(file.path(here, "..", "stats.R"))

check <- function(name, ok) {
  cat(if (ok) "PASS" else "FAIL", name, "\n")
  if (!ok) quit(status = 1)
}
near <- function(a, b, tol = 1e-6) abs(a - b) <= tol

check("removal efficiency", near(removal_efficiency(67.1, 67.1 * (1 - 0.867)), 86.7))
check("NH4 absorption rate, Fig 3c day 1",
      near(absorption_rate(67.1, 67.1 * 0.44, 0.05, 1, 0.1), 18.7, 0.2))
check("PO4 absorption rate, Fig 3d day 1",
      near(absorption_rate(29.9, 29.9 * 0.42, 0.05, 1, 0.1), 8.7, 0.1))
check("rate is NA on day 0", is.na(absorption_rate(67.1, 67.1, 0.05, 0, 0.1)))
check("viability 100 % for equal growth", near(cell_viability(0.8, 1.2, 0.8, 1.2, 0.05, 0.05), 100))
check("degradation", near(degradation(0.200, 0.194), 3))
check("chlorophyll a", near(chlorophyll_a(0.01, 0.01, 1.01, 0.01, 2), 5.81))
check("total K", near(total_k(0.5, 0.015), 0.5 * 120 / 0.015))
check("total P", near(total_p(1, 3, 1, 20, 2, 0, 1), 300))
check("arcsine clips >100 %", near(arcsine_transform(150), pi / 2))
check("decision matrix", which.max(decision_matrix(c(219, 110, 52), c(3, 5.3, 4.1))) == 1)

df <- data.frame(g = rep(c("A", "B", "C", "D"), each = 3),
                 v = c(86, 87, 86.5, 81, 82, 80, 54, 55, 54.5, 50, 49, 50.5))
res <- compare_groups(df, "v", "g", method = "kruskal")
check("Kruskal-Wallis H = 10.38 as in Section 3.3", near(res$statistic, 10.38, 0.01) && res$df == 3)

pm <- matrix(c(1, .9, .001, .9, 1, .001, .001, .001, 1), 3, dimnames = list(c("A","B","C"), c("A","B","C")))
check("compact letters", identical(unname(compact_letters(c("A","B","C"), pm)), c("a", "a", "b")))
cat("All R tests passed\n")
