# Statistical workflow from Section 2.13 of the paper (base R only).
#   % data          -> arcsine transform
#   Shapiro-Wilk    -> normal: one-way ANOVA + Tukey HSD
#                   -> non-normal: Kruskal-Wallis + pairwise Mann-Whitney U
#   factorial ANOVA for toxicity / degradation
#   two-way repeated-measures (mixed) ANOVA for the nutrient trials

ALPHA <- 0.05

is_normal <- function(x, g, alpha = ALPHA) {
  for (lev in unique(g)) {
    v <- x[g == lev & !is.na(x)]
    if (length(v) >= 3 && diff(range(v)) > 0 && shapiro.test(v)$p.value < alpha) return(FALSE)
  }
  TRUE
}

# Compact letter display (insert-and-absorb, Piepho 2004).
# pmat: symmetric matrix of pairwise p-values with dimnames = groups.
compact_letters <- function(groups, pmat, alpha = ALPHA) {
  sets <- list(groups)
  for (pair in combn(groups, 2, simplify = FALSE)) {
    a <- pair[1]; b <- pair[2]
    if (is.na(pmat[a, b]) || pmat[a, b] >= alpha) next
    new_sets <- list()
    for (s in sets) {
      if (a %in% s && b %in% s) {
        new_sets <- c(new_sets, list(setdiff(s, a)), list(setdiff(s, b)))
      } else {
        new_sets <- c(new_sets, list(s))
      }
    }
    keep <- vapply(seq_along(new_sets), function(i) {
      !any(vapply(seq_along(new_sets), function(j) {
        if (i == j) return(FALSE)
        si <- new_sets[[i]]; sj <- new_sets[[j]]
        sub <- all(si %in% sj)
        (sub && length(si) < length(sj)) || (sub && length(si) == length(sj) && j < i)
      }, logical(1)))
    }, logical(1))
    sets <- new_sets[keep]
  }
  sets <- sets[order(vapply(sets, function(s) min(match(s, groups)), numeric(1)))]
  out <- setNames(rep("", length(groups)), groups)
  for (i in seq_along(sets)) out[sets[[i]]] <- paste0(out[sets[[i]]], letters[i])
  out
}

# One-factor comparison. method: "auto", "anova" or "kruskal"; transform: NULL or "arcsine".
compare_groups <- function(df, value, group, method = "auto", transform = NULL, alpha = ALPHA) {
  d <- df[!is.na(df[[value]]), c(group, value)]
  y <- d[[value]]
  if (identical(transform, "arcsine")) y <- arcsine_transform(y)
  g <- factor(d[[group]], levels = unique(d[[group]]))
  groups <- levels(g)
  if (method == "auto") method <- if (is_normal(y, g, alpha)) "anova" else "kruskal"

  pmat <- matrix(1, length(groups), length(groups), dimnames = list(groups, groups))
  if (method == "anova") {
    fit <- aov(y ~ g)
    tab <- summary(fit)[[1]]
    tk <- TukeyHSD(fit)$g
    for (nm in rownames(tk)) {
      # group names can contain "-", so match the label against every pair
      for (a in groups) for (b in groups) if (paste(a, b, sep = "-") == nm) {
        pmat[a, b] <- pmat[b, a] <- tk[nm, "p adj"]
      }
    }
    res <- list(test = "One-way ANOVA + Tukey HSD", stat_name = "F",
                statistic = tab[1, "F value"], df = c(tab[1, "Df"], tab[2, "Df"]),
                p = tab[1, "Pr(>F)"], pairwise = as.data.frame(tk))
  } else {
    kw <- kruskal.test(y ~ g)
    rows <- list()
    for (pair in combn(groups, 2, simplify = FALSE)) {
      w <- suppressWarnings(wilcox.test(y[g == pair[1]], y[g == pair[2]]))
      pmat[pair[1], pair[2]] <- pmat[pair[2], pair[1]] <- w$p.value
      rows[[length(rows) + 1]] <- data.frame(group1 = pair[1], group2 = pair[2],
                                             U = unname(w$statistic), p = w$p.value)
    }
    res <- list(test = "Kruskal-Wallis + pairwise Mann-Whitney U", stat_name = "H",
                statistic = unname(kw$statistic), df = unname(kw$parameter),
                p = kw$p.value, pairwise = do.call(rbind, rows))
  }
  res$letters <- compact_letters(groups, pmat, alpha)
  res
}

# Multi-factor ANOVA, e.g. factorial_anova(tox, viability_pct ~ binder * inoculum)
factorial_anova <- function(df, formula) summary(aov(formula, data = df))

# Two-way repeated-measures (mixed) ANOVA: day within subject, group between
mixed_anova <- function(df, dv, within, between, subject) {
  d <- df
  d[[within]] <- factor(d[[within]]); d[[between]] <- factor(d[[between]])
  d[[subject]] <- factor(d[[subject]])
  f <- as.formula(sprintf("%s ~ %s * %s + Error(%s/%s)", dv, between, within, subject, within))
  summary(aov(f, data = d))
}

format_result <- function(name, res) {
  dfs <- paste(res$df, collapse = ", ")
  sig <- if (res$p < ALPHA) "significant" else "not significant"
  lt <- paste(names(res$letters), res$letters, sep = ": ", collapse = ", ")
  sprintf("%s\n  %s: %s = %.3f, DF = %s, P = %.4f (%s)\n  Letters -> %s\n",
          name, res$test, res$stat_name, res$statistic, dfs, res$p, sig, lt)
}
