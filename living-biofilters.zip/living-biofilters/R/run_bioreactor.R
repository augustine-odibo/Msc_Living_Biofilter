# Bioreactor model (R): simulate with the fitted parameters, or refit them.
#
#   Rscript R/run_bioreactor.R                  # use models/fitted_parameters.json
#   Rscript R/run_bioreactor.R data/raw --fit   # refit to your nutrients.csv (slower)
#
# Outputs go to results/bioreactor_R/.
suppressPackageStartupMessages({
  library(dplyr); library(tidyr); library(readr); library(ggplot2); library(jsonlite)
})
arg <- grep("^--file=", commandArgs(FALSE), value = TRUE)
R_DIR <- if (length(arg)) dirname(normalizePath(sub("^--file=", "", arg))) else "R"
ROOT <- normalizePath(file.path(R_DIR, ".."))
source(file.path(R_DIR, "bioreactor_model.R"))

args <- commandArgs(trailingOnly = TRUE)
do_fit <- "--fit" %in% args
args <- setdiff(args, "--fit")
DATA <- if (length(args) >= 1) args[1] else file.path(ROOT, "data", "example")
OUT <- file.path(ROOT, "results", "bioreactor_R")
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)
ALGAE_FRACTION <- c("3:1" = 0.75, "1:1" = 0.50, "1:3" = 0.25)
MODE <- c(I = "immobilized", S = "suspended")
FIT <- list(mu_max_a = c(0.05, 10), rho_max_P = c(0.5, 200), mu_max_b = c(0.01, 20),
            q_max_N = c(0.1, 100), q_max_P = c(0.05, 50))

# ------------------------------------------------------------------ data
nut <- read_csv(file.path(DATA, "nutrients.csv"), show_col_types = FALSE)
c0 <- nut %>% filter(day == 0) %>%
  select(ratio, system, replicate, nh4_0 = nh4_mg_l, po4_0 = po4_mg_l)
obs <- nut %>% left_join(c0, by = c("ratio", "system", "replicate")) %>%
  mutate(nh4_removal_pct = (1 - nh4_mg_l / nh4_0) * 100,
         po4_removal_pct = (1 - po4_mg_l / po4_0) * 100) %>%
  group_by(ratio, system, day) %>%
  summarise(across(c(nh4_removal_pct, po4_removal_pct), mean), biomass_g = mean(initial_biomass_g),
            nh4_0 = mean(nh4_0), po4_0 = mean(po4_0), .groups = "drop")

reactor_for <- function(g, system, ratio)
  wastewater_reactor(MODE[[system]], g$biomass_g[1], ALGAE_FRACTION[[ratio]],
                     nh4_mg_l = g$nh4_0[1], po4_mg_l = g$po4_0[1])

predict_system <- function(p, system) {
  bind_rows(lapply(split(filter(obs, system == !!system), ~ratio), function(g) {
    out <- simulate(p, reactor_for(g, system, g$ratio[1]), t_end = max(g$day))
    i <- vapply(g$day, function(d) which.min(abs(out$t - d)), integer(1))
    mutate(g, nh4_model = out$nh4_removal_pct[i], po4_model = out$po4_removal_pct[i])
  }))
}

# ------------------------------------------------------------ parameters
pfile <- file.path(ROOT, "models", "fitted_parameters.json")
params <- list()
if (!do_fit && file.exists(pfile)) {
  saved <- fromJSON(pfile)
  for (s in c("I", "S")) params[[s]] <- modifyList(default_params(), saved[[s]]$params)
  cat("Loaded parameters from", pfile, "\n")
} else {
  for (s in c("I", "S")) {
    cat("Fitting system", s, "...\n")
    lo <- log(sapply(FIT, `[`, 1)); hi <- log(sapply(FIT, `[`, 2))
    obj <- function(lx) {
      lx <- pmin(pmax(lx, lo), hi)                       # keep inside bounds
      p <- modifyList(default_params(), as.list(setNames(exp(lx), names(FIT))))
      pr <- filter(predict_system(p, s), day > 0)
      sum((pr$nh4_model - pr$nh4_removal_pct)^2 + (pr$po4_model - pr$po4_removal_pct)^2)
    }
    # start from the saved fit when there is one (Nelder-Mead is sensitive to the start)
    start <- if (file.exists(pfile)) fromJSON(pfile)[[s]]$params else default_params()
    x0 <- pmin(pmax(log(unlist(start[names(FIT)])), lo + 1e-6), hi - 1e-6)
    # Nelder-Mead, bounded by clamping; a few minutes per system
    fit <- optim(x0, obj, method = "Nelder-Mead", control = list(maxit = 300, reltol = 1e-5))
    best <- exp(pmin(pmax(fit$par, lo), hi))
    params[[s]] <- modifyList(default_params(), as.list(setNames(best, names(FIT))))
    cat(sprintf("  RMSE = %.2f %%\n", sqrt(fit$value / 16)))
  }
}
tab <- data.frame(parameter = names(FIT),
                  immobilized = unlist(params$I[names(FIT)]),
                  suspended = unlist(params$S[names(FIT)]))
write_csv(tab, file.path(OUT, "fitted_parameters.csv"))
print(tab, row.names = FALSE)

# --------------------------------------------------------- model vs data
cmp <- bind_rows(predict_system(params$I, "I"), predict_system(params$S, "S"))
write_csv(cmp, file.path(OUT, "model_vs_data.csv"))
cat(sprintf("RMSE (all points, day > 0): %.2f %%\n",
            with(filter(cmp, day > 0), sqrt(mean(c(nh4_model - nh4_removal_pct,
                                                     po4_model - po4_removal_pct)^2)))))

sims <- bind_rows(lapply(split(obs, list(obs$ratio, obs$system), drop = TRUE), function(g) {
  s <- g$system[1]; r <- g$ratio[1]
  simulate(params[[s]], reactor_for(g, s, r), 7) %>% mutate(ratio = r, system = s)
}))
write_csv(sims, file.path(OUT, "simulations.csv"))

long_sim <- sims %>% select(t, ratio, system, NH4 = nh4_removal_pct, PO4 = po4_removal_pct) %>%
  pivot_longer(c(NH4, PO4), names_to = "nutrient")
long_obs <- obs %>% select(day, ratio, system, NH4 = nh4_removal_pct, PO4 = po4_removal_pct) %>%
  pivot_longer(c(NH4, PO4), names_to = "nutrient")
p <- ggplot() +
  geom_line(data = long_sim, aes(t, value, colour = ratio, linetype = system)) +
  geom_point(data = long_obs, aes(day, value, colour = ratio, shape = system), size = 2) +
  facet_wrap(~nutrient) +
  scale_colour_manual(values = c("3:1" = "#C00000", "1:1" = "#2E75B6")) +
  scale_shape_manual(values = c(I = 16, S = 0)) +
  labs(x = "Time (day)", y = "% removal", title = "Kinetic model (lines) vs measured means (points)") +
  theme_classic(base_size = 10)
ggsave(file.path(OUT, "model_fit.png"), p, width = 10, height = 4.2, dpi = 300)

# ------------------------------------------- photobioreactor scenario
p_pbr <- modifyList(default_params(), list(mu_max_a = 1.5, kLa = 50, q_max_N = 0, q_max_P = 0))
pbr <- simulate(p_pbr, bg11_pbr(), t_end = 14)
write_csv(pbr, file.path(OUT, "pbr_bg11_simulation.csv"))
ggsave(file.path(OUT, "pbr_bg11.png"),
       ggplot(pbr, aes(t, Xa_g_l)) + geom_line(colour = "#548235") +
         labs(x = "Time (day)", y = "C. vulgaris (g/L)", title = "BG-11, 5 L, 2000 lx, 12:12 h") +
         theme_classic(base_size = 10), width = 5.5, height = 4, dpi = 300)
cat(sprintf("PBR: %.3f -> %.3f g/L after 14 days\nResults in %s\n",
            pbr$Xa_g_l[1], tail(pbr$Xa_g_l, 1), OUT))
