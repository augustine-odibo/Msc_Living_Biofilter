# Figures in the layout of Figs. 2-6 of the paper (ggplot2).
suppressPackageStartupMessages({
  library(ggplot2); library(dplyr); library(tidyr)
})

RATIO_COLORS <- c(CV = "#7F7F7F", BS = "#B0B0B0", "3:1" = "#C00000", "1:1" = "#FFC000", "1:3" = "#548235")
TREATMENT_COLORS <- c("#F28030", "#FFC20E", "#6AA84F", "#990000", "#8B6508")
PLANT_COLORS <- c("Morning glory" = "#FFC000", "Sunflower" = "#C00000", "Cucumber" = "#548235")

theme_paper <- theme_classic(base_size = 10) +
  theme(strip.background = element_blank(), strip.text = element_text(face = "bold"))

fig_binder_screen <- function(summ, ylab, path) {
  summ$inoculum <- factor(summ$inoculum, levels = names(RATIO_COLORS))
  p <- ggplot(summ, aes(inoculum, mean, fill = inoculum)) +
    geom_col(width = 0.7) +
    geom_errorbar(aes(ymin = mean - sd, ymax = mean + sd), width = 0.2) +
    geom_text(aes(y = mean + sd, label = letter), vjust = -0.6, size = 3) +
    geom_vline(xintercept = 2.5, linetype = "dashed", colour = "grey50") +
    facet_wrap(~binder, ncol = 1) +
    scale_fill_manual(values = RATIO_COLORS, guide = "none") +
    labs(x = "Single culture  |  Mixing ratio (CV/BS)", y = ylab) + theme_paper
  ggsave(path, p, width = 5.5, height = 6.4, dpi = 300)
}

fig_nutrients <- function(summ, path) {
  long <- summ %>%
    pivot_longer(c(starts_with("nh4"), starts_with("po4")),
                 names_to = c("var", ".value"), names_pattern = "(.*)_(mean|sd)$") %>%
    filter(!(grepl("rate", var) & day == 0)) %>%
    mutate(var = factor(var,
             levels = c("nh4_removal_pct", "po4_removal_pct", "nh4_rate", "po4_rate"),
             labels = c("(a) % NH4+ removal efficiency", "(b) % PO4 3- removal efficiency",
                        "(c) NH4+ absorption rate (mg/day/g)", "(d) PO4 3- absorption rate (mg/day/g)")),
           group = paste0(ratio, "_CV/BS_", system))
  p <- ggplot(long, aes(day, mean, colour = ratio, linetype = system, shape = system, group = group)) +
    geom_line() + geom_point(size = 2, fill = "white") +
    geom_errorbar(aes(ymin = mean - sd, ymax = mean + sd), width = 0.15, linetype = 1) +
    facet_wrap(~var, scales = "free_y", ncol = 2) +
    scale_colour_manual(values = c("3:1" = "#C00000", "1:1" = "#2E75B6")) +
    scale_linetype_manual(values = c(I = "solid", S = "dashed")) +
    scale_shape_manual(values = c(I = 16, S = 21)) +
    labs(x = "Time (Day)", y = NULL, colour = "CV/BS", linetype = "System", shape = "System") +
    theme_paper
  ggsave(path, p, width = 10, height = 8, dpi = 300)
}

fig_plant_lengths <- function(summ, treatments, path) {
  parts <- c(total_height_cm = "Total plant growth", leaf_cm = "Leaf", branch_cm = "Branch",
             stem_cm = "Stem", root_cm = "Root")
  d <- summ %>% filter(variable %in% names(parts)) %>%
    mutate(part = factor(parts[variable], levels = parts),
           treatment = factor(treatment, levels = treatments),
           plant = factor(plant, levels = names(PLANT_COLORS)))
  p <- ggplot(d, aes(part, mean, fill = treatment)) +
    geom_col(position = position_dodge(0.85), width = 0.8) +
    geom_errorbar(aes(ymin = mean - sd, ymax = mean + sd), position = position_dodge(0.85), width = 0.25) +
    geom_text(aes(y = mean + sd, label = letter), position = position_dodge(0.85), vjust = -0.5, size = 2.5) +
    facet_wrap(~plant, ncol = 1, scales = "free_y") +
    scale_fill_manual(values = TREATMENT_COLORS) +
    labs(x = "Length of plant parts", y = "Plant length (cm)", fill = NULL) + theme_paper
  ggsave(path, p, width = 10, height = 10, dpi = 300)
}

fig_grid <- function(summ, variables, treatments, path) {
  d <- summ %>% filter(variable %in% names(variables)) %>%
    mutate(variable = factor(variables[variable], levels = variables),
           treatment = factor(treatment, levels = treatments),
           plant = factor(plant, levels = names(PLANT_COLORS)))
  p <- ggplot(d, aes(treatment, mean, fill = plant)) +
    geom_col(width = 0.7) +
    geom_errorbar(aes(ymin = mean - sd, ymax = mean + sd), width = 0.2) +
    geom_text(aes(y = mean + sd, label = letter), vjust = -0.6, size = 2.8) +
    facet_grid(plant ~ variable, scales = "free_y") +
    scale_fill_manual(values = PLANT_COLORS, guide = "none") +
    scale_x_discrete(labels = function(x) gsub(" \\(", "\n(", x)) +
    labs(x = "Conditions", y = NULL) + theme_paper +
    theme(axis.text.x = element_text(size = 6))
  ggsave(path, p, width = 12, height = 9, dpi = 300)
}
