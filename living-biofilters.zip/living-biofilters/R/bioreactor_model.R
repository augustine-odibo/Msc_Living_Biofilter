# Kinetic (0-D) bioreactor model for the C. vulgaris / B. subtilis co-culture.
# Same equations as python/bioreactor/model.py (see that file for full notes).
# Units: biomass g, solutes mg/L, volume L, time day.
suppressPackageStartupMessages(library(deSolve))

NH4_TO_N <- 14.007 / 18.038
PO4_TO_P <- 30.974 / 94.971
STATE <- c("Xa", "Qp", "Xb", "N", "P", "G", "O", "SN", "SP")

default_params <- function() list(
  mu_max_a = 1.5, b_a = 0.05, K_Na = 1.0, i_N_a = 0.08, Q_min = 0.002, Q_max = 0.030,
  rho_max_P = 15.0, K_P = 0.5, Y_O2_a = 1.3,
  I0_lux = 2000, lux_to_umol = 0.0135, K_I = 20, K_a = 0.15, light_fraction = 0.5,
  mu_max_b = 2.0, b_b = 0.1, K_G = 20, K_O = 0.5, K_Nb = 1.0, K_Pb = 0.1, Y_G = 0.5,
  i_N_b = 0.12, i_P_b = 0.02,
  q_max_N = 5.0, q_max_P = 3.0, K_s = 5.0, k_s = 10.0,
  kLa = 5.0, O_sat = 8.2)

wastewater_reactor <- function(mode, biomass_g, algae_fraction, Q0 = 0.01,
                               nh4_mg_l = 67.1, po4_mg_l = 29.9, glucose_mg_l = 450) {
  imm <- mode == "immobilized"
  list(mode = mode, V_L = 0.050,
       V_cells = if (imm) 0.0032 else 0.050, depth_m = if (imm) 0.001 else 0.0156,
       bacteria = TRUE,
       init = c(Xa = biomass_g * algae_fraction, Qp = Q0, Xb = biomass_g * (1 - algae_fraction),
                N = nh4_mg_l * NH4_TO_N, P = po4_mg_l * PO4_TO_P, G = glucose_mg_l, O = 8.2,
                SN = 0, SP = 0))
}

bg11_pbr <- function(volume_l = 5, depth_m = 0.08, x0_g_l = 0.05, Q0 = 0.01) {
  list(mode = "pbr", V_L = volume_l, V_cells = volume_l, depth_m = depth_m, bacteria = FALSE,
       init = c(Xa = x0_g_l * volume_l, Qp = Q0, Xb = 0, N = 1500 * 14.007 / 84.995,
                P = 40 * 30.974 / 174.18, G = 0, O = 8.2, SN = 0, SP = 0))
}

light_factor <- function(p, Xa, r, t) {
  if ((t %% 1) >= p$light_fraction) return(0)
  I0 <- p$I0_lux * p$lux_to_umol
  tau <- p$K_a * max(Xa, 0) / r$V_cells * 1000 * r$depth_m
  I_av <- if (tau < 1e-9) I0 else I0 * (1 - exp(-tau)) / tau
  I_av / (p$K_I + I_av)
}

rates <- function(t, y, parms) {
  p <- parms$p; r <- parms$r
  y <- pmax(y, 0)
  Xa <- y[["Xa"]]; Qp <- max(y[["Qp"]], p$Q_min * 1.0001); Xb <- y[["Xb"]]
  N <- y[["N"]]; P <- y[["P"]]; G <- y[["G"]]; O <- y[["O"]]; SN <- y[["SN"]]; SP <- y[["SP"]]
  fI <- light_factor(p, Xa, r, t)
  mu_a <- p$mu_max_a * fI * N / (p$K_Na + N) * (1 - p$Q_min / Qp)
  rho_P <- p$rho_max_P * P / (p$K_P + P) * max(p$Q_max - Qp, 0) / (p$Q_max - p$Q_min)
  mu_b <- if (r$bacteria && Xb > 0)
    p$mu_max_b * G / (p$K_G + G) * O / (p$K_O + O) * N / (p$K_Nb + N) * P / (p$K_Pb + P) else 0
  ga <- mu_a * Xa; gb <- mu_b * Xb; VL <- r$V_L; X <- Xa + Xb
  dSN <- p$k_s * (p$q_max_N * X * N / (p$K_s + N) - SN)
  dSP <- p$k_s * (p$q_max_P * X * P / (p$K_s + P) - SP)
  list(c(
    Xa = ga - p$b_a * Xa,
    Qp = rho_P / 1000 - mu_a * Qp,
    Xb = gb - p$b_b * Xb,
    N = -(p$i_N_a * ga + p$i_N_b * gb) * 1000 / VL - dSN / VL,
    P = -(rho_P * Xa + p$i_P_b * gb * 1000) / VL - dSP / VL,
    G = -(gb / p$Y_G) * 1000 / VL,
    O = (p$Y_O2_a * ga - gb * (1 - p$Y_G) / p$Y_G * 1.07) * 1000 / VL + p$kLa * (p$O_sat - O),
    SN = dSN, SP = dSP))
}

simulate <- function(p, r, t_end = 7, n_out = NULL) {
  times <- seq(0, t_end, length.out = if (is.null(n_out)) t_end * 48 + 1 else n_out)
  out <- as.data.frame(ode(r$init[STATE], times, rates, list(p = p, r = r),
                           method = "lsoda", hmax = 0.02, rtol = 1e-6, atol = 1e-9))
  names(out)[1] <- "t"
  out$NH4_mg_l <- out$N / NH4_TO_N
  out$PO4_mg_l <- out$P / PO4_TO_P
  out$nh4_removal_pct <- (1 - out$N / r$init[["N"]]) * 100
  out$po4_removal_pct <- if (r$init[["P"]] > 0) (1 - out$P / r$init[["P"]]) * 100 else 0
  out$Xa_g_l <- out$Xa / r$V_L
  out
}
