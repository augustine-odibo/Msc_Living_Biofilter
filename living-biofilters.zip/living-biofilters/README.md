# Living biofilters: microalgal-bacterial co-culture for nutrient recovery and biofertilizer

Analysis code (Python and R) for:

> Odibo, A., Janpum, C., Pombubpa, N., Monshupanee, T., Incharoensakdi, A., Rehman, Z. U., & In-na, P. (2024).
> **Microalgal-bacterial immobilized co-culture as living biofilters for nutrient recovery from synthetic wastewater and their potential as biofertilizers.**
> *Bioresource Technology*, 398, 130509. https://doi.org/10.1016/j.biortech.2024.130509

Living biofilters were made by immobilizing *Chlorella vulgaris* TISTR 8580 (CV) and *Bacillus subtilis* TISTR 1415 (BS) on cotton textile with guar gum (GG) or guar gum/carrageenan (GG/CG) binders. They were used to treat synthetic municipal wastewater for 7 days, then dried and applied as biofertilizer to morning glory, sunflower and cucumber for 20 days.

This repository:

* implements every calculation and statistical test in the paper and redraws Figs. 2-6 (Python and R give the same statistics);
* provides a **kinetic bioreactor model** of the microalgae–bacteria culture, in Python and R, calibrated to the 7-day nutrient-removal data, plus a photobioreactor scenario for growing *C. vulgaris* in BG-11;
* provides a **COMSOL Multiphysics model** of the treatment bottle with the living biofilter, using the same kinetics with diffusion through the gel layer.

## What the code does

| Paper section | Calculation | Python | R |
|---|---|---|---|
| 2.3 / 3.1 | % cell viability (OD750) | `cell_viability()` | `cell_viability()` |
| 2.4 / 3.2 | % degradation of biofilters | `degradation()` | `degradation()` |
| 2.4 | Decision matrix for binder / ratio choice | `decision_matrix()` | `decision_matrix()` |
| 2.5 / 3.3 | % NH4+ and PO4 3- removal efficiency | `removal_efficiency()` | `removal_efficiency()` |
| 2.5 / 3.3 | Nutrient absorption rate (mg day-1 g-1) | `absorption_rate()` | `absorption_rate()` |
| 2.10 / 3.7 | Chlorophyll a per dried plant biomass | `chlorophyll_a()` | `chlorophyll_a()` |
| 2.12 / 3.8 | Soil total N (Kjeldahl), P, K | `total_n()`, `total_p()`, `total_k()` | same |
| 2.13 | Arcsine transform, Shapiro-Wilk, ANOVA + Tukey, Kruskal-Wallis + Mann-Whitney U, mixed ANOVA, letter display | `biofilter/stats.py` | `R/stats.R` |

## Repository layout

```
├── python/
│   ├── biofilter/            equations.py, stats.py, plots.py
│   ├── bioreactor/           model.py (kinetic model), calibrate.py
│   ├── run_analysis.py       statistics pipeline
│   ├── run_bioreactor.py     model calibration + scenarios
│   ├── make_example_data.py  regenerates data/example/
│   └── tests/
├── R/
│   ├── equations.R  stats.R  plots.R  bioreactor_model.R
│   ├── run_analysis.R        statistics pipeline
│   ├── run_bioreactor.R      model simulation (and optional refit)
│   └── tests/
├── comsol/
│   ├── LivingBiofilter.java  COMSOL Multiphysics model (Java API)
│   ├── parameters_fitted.txt kinetic parameters for COMSOL
│   ├── preview_1d.py         same equations in 1D, no licence needed
│   └── README.md             how to build/run, GUI guide
├── models/
│   └── fitted_parameters.json  shared by Python, R and COMSOL
├── data/
│   ├── templates/            empty CSVs with the required columns
│   ├── example/              simulated data (see note below)
│   └── raw/                  put your own measurements here
└── results/                  created when you run the pipelines
```

## Quick start

**Python** (3.9+)

```bash
pip install -r requirements.txt
python python/run_analysis.py                    # runs on data/example
python python/run_analysis.py --data data/raw    # runs on your data
pytest python/tests
```

**R** (4.1+)

```r
install.packages(c("dplyr", "tidyr", "readr", "ggplot2", "deSolve", "jsonlite"))
```
```bash
Rscript R/run_analysis.R                 # runs on data/example
Rscript R/run_analysis.R data/raw        # runs on your data
Rscript R/tests/test_equations.R
```

Results go to `results/python/` or `results/R/`: processed tables, summary tables (mean and SD), `statistics_report.txt`, and figures `fig2ab` to `fig6`.

### Options

* `--paper-methods` forces the tests used in the paper: ANOVA for morning glory, Kruskal-Wallis for sunflower and cucumber. By default the test is picked for each variable by Shapiro-Wilk, as Section 2.13 describes.
* `--chl-extract-ml` (Python) multiplies the Chl a result by the ethanol extract volume. The default of 1 matches the equation as printed; use 1.5 to report µg chlorophyll per g biomass.

## Input data

Copy the headers from `data/templates/` into `data/raw/` and fill in one row per replicate.

| File | Columns |
|---|---|
| `toxicity.csv` | binder (`GG`, `GG/CG`), culture (`single`, `co-culture`), inoculum (`CV`, `BS`, `3:1`, `1:1`, `1:3`), replicate, OD750 of sample, control and blank on day 0 and day 7 |
| `degradation.csv` | binder, culture, inoculum, replicate, dried weight (g) on day 0 and day 7 |
| `nutrients.csv` | ratio (`3:1`, `1:1`), system (`I` immobilized, `S` suspended), replicate, day (include day 0), NH4+ and PO4 3- (mg/L), working volume (L), initial dry biomass (g) |
| `plants.csv` | plant, treatment, replicate, lengths (cm) of total height, leaf, branch, stem and root, dry biomass (g), A630, A645, A663, A750 |
| `soil.csv` | plant, treatment, replicate, soil pH, soil weight (kg), Kjeldahl titrant volume and acid normality, P inputs (C, V1, M, V2, V3, H), K optical density |

Treatment names must be exactly: `Control`, `Chemical fertilizer`, `Biofilter (CV/BS 3:1)`, `Biofilter (CV/BS 1:1)`, `Biofilter control`.

## Bioreactor model

`python/bioreactor/model.py` (and `R/bioreactor_model.R`) is an ODE model of one treatment bottle. Time is in days, biomass in g and solutes in mg/L.

| Process | Equation |
|---|---|
| Algal growth (Monod–Droop) | μa = μmax,a · f(I) · N/(K_N+N) · (1 − Q_min/Q_P) |
| Luxury P uptake into the cell quota | ρP = ρmax · P/(K_P+P) · (Q_max−Q_P)/(Q_max−Q_min) |
| Light | depth-averaged Beer–Lambert through the gel (immobilized) or the liquid (suspended), 2000 lx, 12:12 h |
| Bacterial growth (*B. subtilis*) | μb = μmax,b · G/(K_G+G) · O₂/(K_O+O₂) · N/(K_N+N) · P/(K_P+P) |
| Oxygen | produced by algae, used by bacteria, exchanged with the headspace (k_La) |
| Fast uptake on day 1 | sorption/precipitation pool for N and P (the extracellular stage described in Section 3.3) |

```bash
python python/run_bioreactor.py                 # fit to data/example, run scenarios
python python/run_bioreactor.py --data data/raw # fit to your nutrients.csv
Rscript R/run_bioreactor.R                      # R: simulate with the fitted parameters
Rscript R/run_bioreactor.R data/raw --fit       # R: refit (a few minutes)
```

Five parameters are fitted separately for the immobilized and suspended systems (μmax,a, ρmax,P, μmax,b, and the N and P sorption capacities). Everything else is set to typical literature values in `Params`. On the example data the fit has an RMSE of about 7% removal (immobilized) and 10% (suspended). Outputs in `results/bioreactor/` are the fit (`model_fit.png`), internal states (`model_states.png`: algal biomass, P quota, O₂, glucose), and a 14-day BG-11 photobioreactor run (`pbr_bg11.png`; change it with `--pbr-volume`, `--pbr-lux`, `--pbr-days`).

**Limits.** Only N and P concentrations were measured, so several parameters are only weakly identifiable. For example, in the example fit most day-1 removal is attributed to fast sorption, and algal biomass slowly declines. Adding biomass or OD750 measurements over the 7 days would constrain the growth parameters much better. Treat the fitted values as effective parameters for this setup, not as intrinsic constants of the strains.

## COMSOL Multiphysics model

`comsol/LivingBiofilter.java` builds a 2D model of the bottle: liquid above a 1 mm gel layer holding the cells. NH₄⁺, PO₄³⁻, glucose and O₂ diffuse into the gel, where the kinetics above apply locally, with light decaying through the gel. It reads `comsol/parameters_fitted.txt`, which `run_bioreactor.py` writes. See [`comsol/README.md`](comsol/README.md) to compile and run it, or to build it step by step in the GUI. To check the equations without a licence, run `python comsol/preview_1d.py`.

## About the example data

The files in `data/example/` are **simulated**, not the original lab measurements. They are random draws (n = 3, fixed seed) around the means and standard deviations reported in the paper, so that the code can be run and tested out of the box. The figures they produce look like the published ones but will not match them value for value. Replace them with the raw data before reporting any results.

The tests check the equations against numbers in the paper. For example, the 1:1 living biofilter's day 1 absorption rates (18.7 mg NH4+ and 8.7 mg PO4 3- per day per g biomass) are recovered with 50 mL and about 0.1 g biomass, and the Kruskal-Wallis result for nutrient removal (H = 10.38, DF = 3) is reproduced.

## Notes on the statistics

* Toxicity and degradation use a two-factor ANOVA (binder x inoculum). The paper describes a three-factor design with culture type as a third factor, but culture type is fully determined by inoculum (CV and BS are single culture, the ratios are co-culture), so it cannot be estimated as a separate term.
* With n = 3 per group, the exact two-sided Mann-Whitney U test cannot reach P < 0.05 (the smallest possible P is 0.1). Kruskal-Wallis can still be significant while every pairwise letter is "a". This is a property of the sample size, not a bug.
* The mixed ANOVA treats day as the within-subject factor and the ratio-system group as the between-subject factor, using arcsine-transformed removal (%).

## Citation

If you use this code, please cite the paper above. A `CITATION.cff` file is included so GitHub shows a "Cite this repository" button.

## License

MIT. See `LICENSE`.
