"""Fit kinetic parameters of the bioreactor model to measured removal curves."""
from __future__ import annotations

from dataclasses import replace

import numpy as np
import pandas as pd
from scipy.optimize import least_squares

from .model import Params, Reactor, simulate

ALGAE_FRACTION = {"3:1": 0.75, "1:1": 0.50, "1:3": 0.25}
MODE = {"I": "immobilized", "S": "suspended"}

# parameters estimated from data; everything else stays at the literature-type default
FIT = {"mu_max_a": (0.05, 10.0), "rho_max_P": (0.5, 200.0), "mu_max_b": (0.01, 20.0),
       "q_max_N": (0.1, 100.0), "q_max_P": (0.05, 50.0)}


def observed_means(nutrients: pd.DataFrame) -> pd.DataFrame:
    """Mean removal (%) per ratio, system and day, plus mean initial biomass and C0."""
    d = nutrients.copy()
    c0 = d[d.day == 0].groupby(["ratio", "system", "replicate"])[["nh4_mg_l", "po4_mg_l"]].first()
    d = d.join(c0, on=["ratio", "system", "replicate"], rsuffix="_0")
    d["nh4_removal_pct"] = (1 - d.nh4_mg_l / d.nh4_mg_l_0) * 100
    d["po4_removal_pct"] = (1 - d.po4_mg_l / d.po4_mg_l_0) * 100
    return (d.groupby(["ratio", "system", "day"], as_index=False)
              .agg(nh4_removal_pct=("nh4_removal_pct", "mean"),
                   po4_removal_pct=("po4_removal_pct", "mean"),
                   biomass_g=("initial_biomass_g", "mean"),
                   nh4_0=("nh4_mg_l_0", "mean"), po4_0=("po4_mg_l_0", "mean")))


def reactor_for(group: pd.DataFrame, system: str, ratio: str) -> Reactor:
    g0 = group.iloc[0]
    return Reactor.wastewater(MODE[system], g0.biomass_g, ALGAE_FRACTION[ratio],
                              nh4_mg_l=g0.nh4_0, po4_mg_l=g0.po4_0)


def predict(p: Params, obs: pd.DataFrame, system: str) -> pd.DataFrame:
    rows = []
    for ratio, g in obs[obs.system == system].groupby("ratio"):
        out = simulate(p, reactor_for(g, system, ratio), t_end=float(g.day.max()))
        for day in g.day:
            i = int(np.argmin(np.abs(out["t"] - day)))
            rows.append(dict(ratio=ratio, system=system, day=day,
                             nh4_pred=out["nh4_removal_pct"][i],
                             po4_pred=out["po4_removal_pct"][i]))
    return obs[obs.system == system].merge(pd.DataFrame(rows), on=["ratio", "system", "day"])


def fit_system(obs: pd.DataFrame, system: str, base: Params | None = None):
    """Least-squares fit (log-scaled) of FIT parameters for one system ('I' or 'S')."""
    base = base or Params()
    names = list(FIT)
    lo = np.log([FIT[n][0] for n in names])
    hi = np.log([FIT[n][1] for n in names])
    x0 = np.log([getattr(base, n) for n in names])

    def resid(logx):
        p = replace(base, **dict(zip(names, np.exp(logx))))
        pr = predict(p, obs, system)
        pr = pr[pr.day > 0]
        return np.concatenate([pr.nh4_pred - pr.nh4_removal_pct,
                               pr.po4_pred - pr.po4_removal_pct])

    res = least_squares(resid, np.clip(x0, lo + 1e-6, hi - 1e-6), bounds=(lo, hi),
                        diff_step=0.05, max_nfev=200)
    p = replace(base, **dict(zip(names, np.exp(res.x))))
    r = resid(res.x)
    stats = dict(rmse_pct=float(np.sqrt(np.mean(r ** 2))), n_points=int(r.size),
                 converged=bool(res.success))
    return p, stats
