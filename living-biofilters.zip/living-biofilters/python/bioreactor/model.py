"""
Kinetic (0-D) bioreactor model for the Chlorella vulgaris / Bacillus subtilis
co-culture used in Odibo et al. (2024).

Two configurations share the same kinetics:

* "immobilized" - cells sit in the GG/CG gel layer on the 4 x 8 cm cotton
  textile (living biofilter); light is attenuated through the gel layer.
* "suspended"   - cells are dispersed in the 50 mL of wastewater; light is
  attenuated through the liquid depth.

A third use, the photobioreactor (PBR) scenario, runs the algae alone in BG-11
(the 5 L stock-culture bottles of Section 2.1).

State variables (units)
-----------------------
Xa  algal biomass             g dry weight (in the reactor)
Qp  algal cell P quota        g P / g algae           (Droop model)
Xb  bacterial biomass         g dry weight
N   ammonium-N in liquid      mg N / L
P   phosphate-P in liquid     mg P / L
G   glucose in liquid         mg / L
O   dissolved oxygen          mg O2 / L
SN  N bound by fast sorption  mg N  (cells, EPS and gel)
SP  P bound by fast sorption / precipitation  mg P

Kinetics
--------
Algae  : mu_a = mu_max_a * f_I * N/(K_Na+N) * (1 - Q_min/Qp)          (Monod-Droop)
         P uptake rho = rho_max_P * P/(K_P+P) * (Q_max-Qp)/(Q_max-Q_min)  (luxury uptake)
Bacteria: mu_b = mu_max_b * G/(K_G+G) * O/(K_O+O) * N/(K_Nb+N) * P/(K_Pb+P)
Light  : depth-averaged Beer-Lambert, I_av = I0 (1 - e^-tau)/tau,
         tau = K_a * X_conc * depth,  f_I = I_av / (K_I + I_av),  12:12 h photoperiod
Oxygen : + algal photosynthesis, - bacterial respiration, + k_La (O_sat - O)
Fast stage (Section 3.3 of the paper: extracellular precipitation / sorption):
         dS/dt = k_s (q_max X C/(K_s + C) - S)   for N and P, X = total biomass

Time is in days.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict

import numpy as np
from scipy.integrate import solve_ivp

# molar-mass conversions between ion and element
NH4_TO_N = 14.007 / 18.038
PO4_TO_P = 30.974 / 94.971


@dataclass
class Params:
    # --- algae (C. vulgaris) ---
    mu_max_a: float = 1.5      # 1/d   max specific growth rate        (fitted)
    b_a: float = 0.05          # 1/d   decay
    K_Na: float = 1.0          # mg N/L  half-saturation, ammonium
    i_N_a: float = 0.08        # g N / g algae
    Q_min: float = 0.002       # g P / g algae  minimum P quota
    Q_max: float = 0.030       # g P / g algae  maximum P quota
    rho_max_P: float = 15.0    # mg P / (g algae d)  max P uptake    (fitted)
    K_P: float = 0.5           # mg P/L
    Y_O2_a: float = 1.3        # g O2 released / g algae grown
    # --- light ---
    I0_lux: float = 2000.0     # lx at the culture surface (Section 2.1)
    lux_to_umol: float = 0.0135  # umol m-2 s-1 per lx (white LED, approx.)
    K_I: float = 20.0          # umol m-2 s-1  light half-saturation
    K_a: float = 0.15          # m2 / g  specific light attenuation of biomass
    light_fraction: float = 0.5  # 12:12 h light:dark
    # --- bacteria (B. subtilis) ---
    mu_max_b: float = 2.0      # 1/d   (fitted)
    b_b: float = 0.1           # 1/d
    K_G: float = 20.0          # mg glucose/L
    K_O: float = 0.5           # mg O2/L
    K_Nb: float = 1.0          # mg N/L
    K_Pb: float = 0.1          # mg P/L
    Y_G: float = 0.5           # g biomass / g glucose
    i_N_b: float = 0.12        # g N / g bacteria
    i_P_b: float = 0.02        # g P / g bacteria
    # --- fast sorption / precipitation stage ---
    q_max_N: float = 5.0       # mg N / g biomass   (fitted)
    q_max_P: float = 3.0       # mg P / g biomass   (fitted)
    K_s: float = 5.0           # mg/L
    k_s: float = 10.0          # 1/d  (fast, approaches equilibrium within hours)
    # --- gas exchange ---
    kLa: float = 5.0           # 1/d  (closed bottle on orbital shaker, 40 rpm)
    O_sat: float = 8.2         # mg/L at 25 C

    def to_dict(self):
        return asdict(self)


@dataclass
class Reactor:
    """Geometry and operating conditions."""
    mode: str = "immobilized"          # "immobilized", "suspended" or "pbr"
    V_L: float = 0.050                 # L liquid
    V_cells: float = 0.0032            # L volume the cells occupy (gel layer 4 x 8 x 0.1 cm)
    depth_m: float = 0.001             # m light path through the cell layer
    bacteria: bool = True
    init: dict = field(default_factory=dict)

    @classmethod
    def wastewater(cls, mode, biomass_g, algae_fraction, Q0=0.01,
                   nh4_mg_l=67.1, po4_mg_l=29.9, glucose_mg_l=450.0):
        """Bottle of 50 mL synthetic wastewater (Section 2.5)."""
        if mode == "immobilized":
            v_cells, depth = 0.0032, 0.001       # 4 x 8 cm textile, ~1 mm gel
        else:
            v_cells, depth = 0.050, 0.0156       # cells in 50 mL, 1.56 cm liquid depth
        init = dict(Xa=biomass_g * algae_fraction, Qp=Q0,
                    Xb=biomass_g * (1 - algae_fraction),
                    N=nh4_mg_l * NH4_TO_N, P=po4_mg_l * PO4_TO_P,
                    G=glucose_mg_l, O=8.2, SN=0.0, SP=0.0)
        return cls(mode=mode, V_L=0.050, V_cells=v_cells, depth_m=depth,
                   bacteria=True, init=init)

    @classmethod
    def bg11_pbr(cls, volume_l=5.0, depth_m=0.08, x0_g_l=0.05, Q0=0.01):
        """C. vulgaris stock culture in BG-11 (Section 2.1): NaNO3 1.5 g/L, K2HPO4 0.04 g/L."""
        n_mg_l = 1500 * 14.007 / 84.995           # ~247 mg N/L (nitrate, treated as N source)
        p_mg_l = 40 * 30.974 / 174.18             # ~7.1 mg P/L
        init = dict(Xa=x0_g_l * volume_l, Qp=Q0, Xb=0.0, N=n_mg_l, P=p_mg_l, G=0.0, O=8.2, SN=0.0, SP=0.0)
        return cls(mode="pbr", V_L=volume_l, V_cells=volume_l, depth_m=depth_m,
                   bacteria=False, init=init)


STATE = ["Xa", "Qp", "Xb", "N", "P", "G", "O", "SN", "SP"]


def light_factor(p: Params, Xa_g, reactor: Reactor, t):
    """Photoperiod x depth-averaged light limitation."""
    on = (t % 1.0) < p.light_fraction
    if not on:
        return 0.0
    I0 = p.I0_lux * p.lux_to_umol
    conc = max(Xa_g, 0.0) / reactor.V_cells * 1000.0       # g/m3
    tau = p.K_a * conc * reactor.depth_m
    I_av = I0 if tau < 1e-9 else I0 * (1 - np.exp(-tau)) / tau
    return I_av / (p.K_I + I_av)


def rates(t, y, p: Params, r: Reactor):
    Xa, Qp, Xb, N, P, G, O, SN, SP = np.maximum(y, 0.0)
    Qp = max(Qp, p.Q_min * 1.0001)
    fI = light_factor(p, Xa, r, t)

    # algae
    mu_a = p.mu_max_a * fI * N / (p.K_Na + N) * (1 - p.Q_min / Qp)
    rho_P = p.rho_max_P * P / (p.K_P + P) * max(p.Q_max - Qp, 0) / (p.Q_max - p.Q_min)  # mg P/g/d
    # bacteria
    if r.bacteria and Xb > 0:
        mu_b = (p.mu_max_b * G / (p.K_G + G) * O / (p.K_O + O)
                * N / (p.K_Nb + N) * P / (p.K_Pb + P))
    else:
        mu_b = 0.0

    growth_a = mu_a * Xa                     # g/d
    growth_b = mu_b * Xb                     # g/d
    dXa = growth_a - p.b_a * Xa
    # quota dilution by growth + uptake (g P/g/d)
    dQp = rho_P / 1000.0 - mu_a * Qp
    dXb = growth_b - p.b_b * Xb

    VL = r.V_L
    X = Xa + Xb
    dSN = p.k_s * (p.q_max_N * X * N / (p.K_s + N) - SN)                    # mg/d
    dSP = p.k_s * (p.q_max_P * X * P / (p.K_s + P) - SP)
    dN = -(p.i_N_a * growth_a + p.i_N_b * growth_b) * 1000.0 / VL - dSN / VL  # mg/L/d
    dP = -(rho_P * Xa + p.i_P_b * growth_b * 1000.0) / VL - dSP / VL
    dG = -(growth_b / p.Y_G) * 1000.0 / VL
    # O2 demand of heterotrophic growth ~ (1 - Y_G)/Y_G * 1.07 g O2 / g biomass
    o2_resp = growth_b * (1 - p.Y_G) / p.Y_G * 1.07
    dO = (p.Y_O2_a * growth_a - o2_resp) * 1000.0 / VL + p.kLa * (p.O_sat - O)
    return [dXa, dQp, dXb, dN, dP, dG, dO, dSN, dSP]


def simulate(p: Params, r: Reactor, t_end=7.0, n_out=None):
    """Integrate the model; returns a dict of arrays (t in days)."""
    y0 = [r.init[k] for k in STATE]
    t_eval = np.linspace(0, t_end, n_out or int(t_end * 48) + 1)
    sol = solve_ivp(rates, (0, t_end), y0, args=(p, r), method="LSODA",
                    t_eval=t_eval, max_step=0.02, rtol=1e-6, atol=1e-9)
    out = {"t": sol.t}
    out.update({k: sol.y[i] for i, k in enumerate(STATE)})
    out["NH4_mg_l"] = out["N"] / NH4_TO_N
    out["PO4_mg_l"] = out["P"] / PO4_TO_P
    out["nh4_removal_pct"] = (1 - out["N"] / r.init["N"]) * 100
    out["po4_removal_pct"] = (1 - out["P"] / r.init["P"]) * 100 if r.init["P"] > 0 else 0
    out["Xa_g_l"] = out["Xa"] / r.V_L
    return out
