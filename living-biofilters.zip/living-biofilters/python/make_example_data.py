"""
Generate EXAMPLE input files in data/example/.

These are SIMULATED raw measurements (n = 3) drawn around the means and SDs
reported in Odibo et al. (2024). They exist so the pipeline can be run and
tested end to end. They are NOT the original lab data - replace them with
your raw measurements in data/raw/ (same column layout) for real analysis.

    python python/make_example_data.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

rng = np.random.default_rng(2024)
OUT = Path(__file__).resolve().parents[1] / "data" / "example"
OUT.mkdir(parents=True, exist_ok=True)
N = 3
TREATMENTS = ["Control", "Chemical fertilizer", "Biofilter (CV/BS 3:1)",
              "Biofilter (CV/BS 1:1)", "Biofilter control"]
PLANTS = ["Morning glory", "Sunflower", "Cucumber"]


def draw(mean, sd, n=N, lo=None):
    x = rng.normal(mean, sd, n)
    return np.clip(x, lo, None) if lo is not None else x


# ---------------------------------------------------------------- toxicity
viab = {  # Fig. 2a/b, % cell viability (mean, sd)
    "GG":    {"CV": (138, 20), "BS": (187, 10), "3:1": (148, 8), "1:1": (110, 25), "1:3": (52, 12)},
    "GG/CG": {"CV": (210, 6),  "BS": (240, 50), "3:1": (175, 8), "1:1": (219, 40), "1:3": (104, 8)},
}
rows = []
blank0, blank7, ctrl_growth = 0.050, 0.052, 0.40
for binder, d in viab.items():
    for inoc, (m, s) in d.items():
        culture = "single" if inoc in ("CV", "BS") else "co-culture"
        for r in range(1, N + 1):
            c0 = 0.80 + rng.normal(0, 0.01)
            c7 = c0 + ctrl_growth + rng.normal(0, 0.01)
            s0 = 0.80 + rng.normal(0, 0.01)
            v = rng.normal(m, s)
            s7 = s0 + (blank7 - blank0) + v / 100 * ((c7 - blank7) - (c0 - blank0))
            rows.append(dict(binder=binder, culture=culture, inoculum=inoc, replicate=r,
                             sample_od_d0=s0, sample_od_d7=s7,
                             control_od_d0=c0, control_od_d7=c7,
                             blank_d0=blank0, blank_d7=blank7))
pd.DataFrame(rows).round(4).to_csv(OUT / "toxicity.csv", index=False)

# ------------------------------------------------------------- degradation
degr = {  # Fig. 2e/f, % degradation
    "GG":    {"CV": (4.7, 3.5), "BS": (3.5, 2.6), "3:1": (5.1, 3.0), "1:1": (5.3, 3.4), "1:3": (4.1, 2.0)},
    "GG/CG": {"CV": (3.9, 1.2), "BS": (2.2, 1.4), "3:1": (3.3, 1.4), "1:1": (3.0, 0.4), "1:3": (4.4, 0.4)},
}
rows = []
for binder, d in degr.items():
    for inoc, (m, s) in d.items():
        culture = "single" if inoc in ("CV", "BS") else "co-culture"
        for r in range(1, N + 1):
            w0 = 0.200 + rng.normal(0, 0.005)
            pct = max(rng.normal(m, s), 0.1)
            rows.append(dict(binder=binder, culture=culture, inoculum=inoc, replicate=r,
                             dry_weight_d0=w0, dry_weight_d7=w0 * (1 - pct / 100)))
pd.DataFrame(rows).round(5).to_csv(OUT / "degradation.csv", index=False)

# --------------------------------------------------------------- nutrients
CI_NH4, CI_PO4 = 67.1, 29.9           # mg/L, Section 2.5
days = [0, 1, 3, 5, 7]
traj = {  # Fig. 3a/b, % removal at each day; initial biomass (g)
    ("1:1", "I"): ([0, 56, 72, 79, 86.7], [0, 58, 96, 98, 99.3], 0.100),
    ("3:1", "I"): ([0, 38, 65, 72, 81.0], [0, 48, 91, 96, 97.5], 0.130),
    ("1:1", "S"): ([0, 38, 43, 49.5, 54.3], [0, 40, 46, 51, 54.6], 0.135),
    ("3:1", "S"): ([0, 36, 40, 46.5, 50.0], [0, 42, 45, 47, 49.0], 0.186),
}
rows = []
for (ratio, system), (nh4, po4, m) in traj.items():
    for r in range(1, N + 1):
        biomass = m * (1 + rng.normal(0, 0.02))
        for day, rn, rp in zip(days, nh4, po4):
            jn = 0 if day == 0 else rng.normal(0, 0.8)
            jp = 0 if day == 0 else rng.normal(0, 0.4)
            rows.append(dict(ratio=ratio, system=system, replicate=r, day=day,
                             nh4_mg_l=CI_NH4 * (1 - min(rn + jn, 100) / 100),
                             po4_mg_l=CI_PO4 * (1 - min(rp + jp, 100) / 100),
                             volume_l=0.05, initial_biomass_g=biomass))
pd.DataFrame(rows).round(4).to_csv(OUT / "nutrients.csv", index=False)

# ------------------------------------------------------------------ plants
# Fig. 4 lengths (cm): total, leaf, branch, stem, root
lengths = {
    "Morning glory": [(20.5, 21, 23, 27.5, 21), (9.6, 6, 8.6, 7.5, 6), (2.3, 3, 4, 3.2, 2.7),
                      (2.4, 2.3, 2.6, 2.5, 2.4), (7, 6.7, 8, 13.4, 5.3)],
    "Sunflower":     [(11.5, 17.2, 22.8, 23.3, 17.3), (3.7, 3.7, 5.5, 4.3, 4.3), (4.5, 3.8, 2, 2.1, 1.2),
                      (6.3, 9.5, 12, 11, 7.3), (3.3, 4.3, 6, 6.8, 4.3)],
    "Cucumber":      [(12.3, 8.2, 13.4, 12.4, 13.1), (3.8, 3.1, 3.8, 3.5, 4.5), (1.6, 1.6, 2.1, 1.4, 1.5),
                      (2.7, 2.2, 3, 2.8, 2.4), (5, 3.2, 6.8, 5.8, 5.4)],
}
# Fig. 5 biomass (g), pH, Chl a (ug/g): (mean, sd) per treatment
biomass = {"Morning glory": [(1.3, .1), (1.2, .5), (0.9, .2), (1.3, .1), (1.1, .3)],
           "Sunflower":     [(1.5, .05), (1.3, .9), (1.5, .2), (1.5, .1), (1.6, .1)],
           "Cucumber":      [(0.9, .4), (1.7, .1), (2.0, .3), (1.7, .5), (1.9, .2)]}
chla = {"Morning glory": [(2.0, 1.0), (2.9, 2.6), (9.5, 4.4), (2.5, 1.5), (20.0, 11.3)],
        "Sunflower":     [(19.1, 2.5), (11.6, 4.8), (10.2, 2.6), (6.0, 3.5), (9.5, 1.6)],
        "Cucumber":      [(8.5, 2.8), (19.4, 12.4), (6.3, 4.3), (12.4, .67), (8.5, 2.8)]}
rows = []
for plant in PLANTS:
    for t_i, trt in enumerate(TREATMENTS):
        for r in range(1, N + 1):
            parts = [max(draw(m[t_i], 0.15 * m[t_i], 1)[0], 0.1) for m in lengths[plant]]
            dw = max(draw(*biomass[plant][t_i], 1)[0], 0.2)
            chl = max(draw(*chla[plant][t_i], 1)[0], 0.5)
            a750, a630, a645 = 0.010, 0.030, 0.050
            # back-solve A663 so the paper's equation returns `chl`
            a663 = a750 + (chl * dw + 2.16 * (a645 - a750) + 0.1 * (a630 - a750)) / 11.62
            rows.append(dict(plant=plant, treatment=trt, replicate=r,
                             total_height_cm=parts[0], leaf_cm=parts[1], branch_cm=parts[2],
                             stem_cm=parts[3], root_cm=parts[4], dry_biomass_g=dw,
                             A630=a630, A645=a645, A663=a663, A750=a750))
pd.DataFrame(rows).round(4).to_csv(OUT / "plants.csv", index=False)

# -------------------------------------------------------------------- soil
ph = {"Morning glory": [(10.2, .2), (8.9, .4), (9.6, .6), (9.3, .2), (9.4, .2)],
      "Sunflower":     [(7.6, .4), (7.4, .2), (8.0, .3), (8.1, .3), (8.2, .05)],
      "Cucumber":      [(8.2, .05), (7.5, .2), (8.4, .1), (8.2, .1), (8.2, .1)]}
npk = {  # (N, P, K) mg/kg means; Fig. 6
    "Morning glory": [(6.1, .22, .3), (7.0, .82, 1.9), (5.9, .24, .2), (6.0, .22, .3), (6.0, .26, .4)],
    "Sunflower":     [(6.0, .28, .2), (6.6, .82, 1.7), (6.0, .24, .2), (6.0, .26, .4), (6.1, .31, .6)],
    "Cucumber":      [(6.2, .40, .5), (6.2, .50, .5), (6.1, .30, .2), (6.2, .30, .04), (5.8, .30, .7)],
}
W = 0.015            # 15 g soil
ACID_N = 0.01        # 0.01 M HCl
V1, M, V2, V3, H = 3.0, 0.87, 20.0, 2.0, 0.0
rows = []
for plant in PLANTS:
    for t_i, trt in enumerate(TREATMENTS):
        n_m, p_m, k_m = npk[plant][t_i]
        for r in range(1, N + 1):
            n_val = max(draw(n_m, 0.04 * n_m, 1)[0], 0.01)
            p_val = max(draw(p_m, 0.15 * p_m, 1)[0], 0.005)
            k_val = max(draw(k_m, 0.25 * k_m, 1)[0], 0.005)
            rows.append(dict(
                plant=plant, treatment=trt, replicate=r,
                soil_ph=draw(*ph[plant][t_i], 1)[0],
                soil_weight_kg=W,
                n_titrant_volume=n_val * W / (ACID_N * 14.01 * 100),
                n_acid_normality=ACID_N,
                p_conc_mg_ml=p_val * (100 - H) * W / ((V1 / M) * (V2 / V3) * 1000),
                p_v_sample=V1, p_acid_molarity=M, p_v_naoh=V2, p_v_molybdate=V3,
                p_dilution_pct=H,
                k_od=k_val * W / (1.2 * 100)))
pd.DataFrame(rows).to_csv(OUT / "soil.csv", index=False, float_format="%.6g")

print(f"Example data written to {OUT}")
