"""
Bioreactor model: calibrate on the 7-day nutrient trials and run scenarios.

    python python/run_bioreactor.py                          # example data
    python python/run_bioreactor.py --data data/raw          # your data
    python python/run_bioreactor.py --skip-fit               # use parameters saved in models/
    python python/run_bioreactor.py --pbr-days 14 --pbr-volume 5

Outputs go to results/bioreactor/. Fitted parameters are also written to
models/fitted_parameters.json (read by the R model) and
comsol/parameters_fitted.txt (load into COMSOL: Parameters > Load from File).
"""
from __future__ import annotations

import argparse
import json
from dataclasses import replace
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from bioreactor.model import Params, Reactor, simulate
from bioreactor.calibrate import FIT, ALGAE_FRACTION, observed_means, fit_system, reactor_for

ROOT = Path(__file__).resolve().parents[1]
STYLE = {("3:1", "I"): ("#C00000", "-"), ("3:1", "S"): ("#C00000", "--"),
         ("1:1", "I"): ("#2E75B6", "-"), ("1:1", "S"): ("#2E75B6", "--")}


def write_comsol_params(params_by_system, path):
    """COMSOL parameter file: name, expression with unit, description."""
    p = params_by_system["I"]
    rows = [
        ("mu_max_a", f"{p.mu_max_a:.6g}[1/d]", "Algae max specific growth rate (fitted, immobilized)"),
        ("b_a", f"{p.b_a:.6g}[1/d]", "Algae decay rate"),
        ("K_Na", f"{p.K_Na:.6g}[g/m^3]", "Ammonium-N half-saturation, algae"),
        ("i_N_a", f"{p.i_N_a:.6g}", "N content of algae (g N/g)"),
        ("Q_min", f"{p.Q_min:.6g}", "Minimum algal P quota (g P/g)"),
        ("Q_max", f"{p.Q_max:.6g}", "Maximum algal P quota (g P/g)"),
        ("rho_max_P", f"{p.rho_max_P / 1000:.6g}[1/d]", "Max P uptake (g P/g algae/d, fitted)"),
        ("K_P", f"{p.K_P:.6g}[g/m^3]", "Phosphate-P half-saturation"),
        ("Y_O2_a", f"{p.Y_O2_a:.6g}", "O2 released per algae grown (g/g)"),
        ("I0", f"{p.I0_lux * p.lux_to_umol:.6g}", "Light at biofilter surface, umol m-2 s-1 (2000 lx)"),
        ("K_I", f"{p.K_I:.6g}", "Light half-saturation, umol m-2 s-1"),
        ("K_a", f"{p.K_a:.6g}[m^2/g]", "Specific light attenuation of biomass"),
        ("mu_max_b", f"{p.mu_max_b:.6g}[1/d]", "Bacteria max specific growth rate (fitted)"),
        ("b_b", f"{p.b_b:.6g}[1/d]", "Bacteria decay rate"),
        ("K_G", f"{p.K_G:.6g}[g/m^3]", "Glucose half-saturation"),
        ("K_O", f"{p.K_O:.6g}[g/m^3]", "O2 half-saturation"),
        ("K_Nb", f"{p.K_Nb:.6g}[g/m^3]", "Ammonium-N half-saturation, bacteria"),
        ("K_Pb", f"{p.K_Pb:.6g}[g/m^3]", "Phosphate-P half-saturation, bacteria"),
        ("Y_G", f"{p.Y_G:.6g}", "Bacterial yield on glucose (g/g)"),
        ("i_N_b", f"{p.i_N_b:.6g}", "N content of bacteria (g N/g)"),
        ("i_P_b", f"{p.i_P_b:.6g}", "P content of bacteria (g P/g)"),
        ("q_max_N", f"{p.q_max_N / 1000:.6g}", "Fast-sorption capacity N (g N/g biomass, fitted)"),
        ("q_max_P", f"{p.q_max_P / 1000:.6g}", "Fast-sorption capacity P (g P/g biomass, fitted)"),
        ("K_s", f"{p.K_s:.6g}[g/m^3]", "Sorption half-saturation"),
        ("k_s", f"{p.k_s:.6g}[1/d]", "Sorption rate constant"),
        ("kLa", f"{p.kLa:.6g}[1/d]", "O2 transfer coefficient, liquid"),
        ("O_sat", f"{p.O_sat:.6g}[g/m^3]", "O2 saturation at 25 C"),
    ]
    with open(path, "w") as fh:
        for name, expr, desc in rows:
            fh.write(f'{name} {expr} "{desc}"\n')


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", default=ROOT / "data" / "example", type=Path)
    ap.add_argument("--out", default=ROOT / "results" / "bioreactor", type=Path)
    ap.add_argument("--skip-fit", action="store_true")
    ap.add_argument("--pbr-days", type=float, default=14.0)
    ap.add_argument("--pbr-volume", type=float, default=5.0, help="L")
    ap.add_argument("--pbr-depth", type=float, default=0.08, help="light path, m")
    ap.add_argument("--pbr-lux", type=float, default=2000.0)
    ap.add_argument("--pbr-mu-max", type=float, default=1.5,
                    help="C. vulgaris max growth rate in BG-11 (1/d); literature range ~1-2")
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    pfile = ROOT / "models" / "fitted_parameters.json"
    pfile.parent.mkdir(exist_ok=True)

    obs = observed_means(pd.read_csv(a.data / "nutrients.csv"))

    # ------------------------------------------------------------ calibration
    if a.skip_fit and pfile.exists():
        saved = json.loads(pfile.read_text())
        params = {s: Params(**saved[s]["params"]) for s in ("I", "S")}
        print(f"Loaded parameters from {pfile}")
    else:
        params, saved = {}, {}
        for s in ("I", "S"):
            print(f"Fitting system {s} ...")
            params[s], st = fit_system(obs, s)
            saved[s] = {"params": params[s].to_dict(), "fit": st,
                        "fitted": list(FIT)}
            print(f"  RMSE = {st['rmse_pct']:.2f} % removal over {st['n_points']} points")
        pfile.write_text(json.dumps(saved, indent=2))
    write_comsol_params(params, ROOT / "comsol" / "parameters_fitted.txt")

    table = pd.DataFrame({s: {k: getattr(params[s], k) for k in FIT} for s in params})
    table.columns = ["Immobilized (I)", "Suspended (S)"]
    table.to_csv(a.out / "fitted_parameters.csv")
    print("\nFitted parameters:\n" + table.round(4).to_string())

    # ------------------------------------------------------ model vs data
    sims, rows = {}, []
    for (ratio, system), g in obs.groupby(["ratio", "system"]):
        out = simulate(params[system], reactor_for(g, system, ratio), t_end=7.0)
        sims[(ratio, system)] = out
        pd.DataFrame(out).to_csv(a.out / f"simulation_{ratio.replace(':', 'to')}_{system}.csv", index=False)
        for _, r in g.iterrows():
            i = int(np.argmin(np.abs(out["t"] - r.day)))
            rows.append(dict(ratio=ratio, system=system, day=r.day,
                             nh4_obs=r.nh4_removal_pct, nh4_model=out["nh4_removal_pct"][i],
                             po4_obs=r.po4_removal_pct, po4_model=out["po4_removal_pct"][i]))
    pd.DataFrame(rows).round(3).to_csv(a.out / "model_vs_data.csv", index=False)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    for ax, n, lab in zip(axes, ("nh4", "po4"), ("NH$_4^+$", "PO$_4^{3-}$")):
        for key, out in sims.items():
            c, ls = STYLE[key]
            g = obs[(obs.ratio == key[0]) & (obs.system == key[1])]
            ax.plot(out["t"], out[f"{n}_removal_pct"], color=c, ls=ls, label=f"{key[0]}_CV/BS_{key[1]} model")
            ax.plot(g.day, g[f"{n}_removal_pct"], "o" if key[1] == "I" else "s", color=c,
                    mfc=c if key[1] == "I" else "white")
        ax.set(xlabel="Time (day)", ylabel=f"% {lab} removal", ylim=(0, 105))
        ax.spines[["top", "right"]].set_visible(False)
    axes[0].legend(fontsize=8, frameon=False)
    fig.suptitle("Kinetic model (lines) vs measured means (markers)", fontsize=10)
    fig.tight_layout()
    fig.savefig(a.out / "model_fit.png", dpi=300)
    plt.close(fig)

    fig, axes = plt.subplots(2, 2, figsize=(11, 7))
    for key, out in sims.items():
        c, ls = STYLE[key]
        lab = f"{key[0]}_CV/BS_{key[1]}"
        axes[0, 0].plot(out["t"], out["Xa"] * 1000, color=c, ls=ls, label=lab)
        axes[0, 1].plot(out["t"], out["Qp"] * 100, color=c, ls=ls)
        axes[1, 0].plot(out["t"], out["O"], color=c, ls=ls)
        axes[1, 1].plot(out["t"], out["G"], color=c, ls=ls)
    for ax, yl in zip(axes.flat, ["Algal biomass (mg)", "Algal P quota (% DW)",
                                   "Dissolved O$_2$ (mg/L)", "Glucose (mg/L)"]):
        ax.set(xlabel="Time (day)", ylabel=yl)
        ax.spines[["top", "right"]].set_visible(False)
    axes[0, 0].legend(fontsize=8, frameon=False)
    fig.tight_layout()
    fig.savefig(a.out / "model_states.png", dpi=300)
    plt.close(fig)

    # ------------------------------------------- photobioreactor scenario
    # axenic culture: literature kinetics, not the wastewater fit (which lumps stress effects)
    p_pbr = Params(mu_max_a=a.pbr_mu_max, I0_lux=a.pbr_lux, kLa=50.0, q_max_N=0.0, q_max_P=0.0)
    pbr = Reactor.bg11_pbr(volume_l=a.pbr_volume, depth_m=a.pbr_depth)
    out = simulate(p_pbr, pbr, t_end=a.pbr_days)
    pd.DataFrame(out).to_csv(a.out / "pbr_bg11_simulation.csv", index=False)
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].plot(out["t"], out["Xa_g_l"], color="#548235")
    ax[0].set(xlabel="Time (day)", ylabel="C. vulgaris (g/L)",
              title=f"BG-11, {a.pbr_volume:g} L, {a.pbr_lux:g} lx, 12:12 h")
    ax[1].plot(out["t"], out["N"], label="N (mg/L)")
    ax[1].plot(out["t"], out["P"] * 10, label="P x10 (mg/L)")
    ax[1].set(xlabel="Time (day)", ylabel="Medium (mg/L)")
    ax[1].legend(frameon=False)
    for x in ax:
        x.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(a.out / "pbr_bg11.png", dpi=300)
    plt.close(fig)
    print(f"\nPBR: {out['Xa_g_l'][0]:.3f} -> {out['Xa_g_l'][-1]:.3f} g/L after {a.pbr_days:g} days")
    print(f"Results in {a.out}")


if __name__ == "__main__":
    main()
