"""
Full analysis pipeline for the living-biofilter study.

    python python/run_analysis.py                       # example data
    python python/run_analysis.py --data data/raw       # your raw data
    python python/run_analysis.py --paper-methods       # force the tests used in the paper

Outputs (tables, statistics report, figures) go to results/python/.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from biofilter import equations as eq
from biofilter import stats as st
from biofilter import plots

ROOT = Path(__file__).resolve().parents[1]
TREATMENTS = ["Control", "Chemical fertilizer", "Biofilter (CV/BS 3:1)",
              "Biofilter (CV/BS 1:1)", "Biofilter control"]
CO_RATIOS = ["3:1", "1:1", "1:3"]
# Section 2.13: morning glory was normal (ANOVA); cucumber & sunflower were not (Kruskal-Wallis)
PAPER_METHOD = {"Morning glory": "anova", "Sunflower": "kruskal", "Cucumber": "kruskal"}


def mean_sd(df, keys, cols):
    g = df.groupby(keys, observed=True, sort=False)[cols]
    out = g.mean().add_suffix("_mean").join(g.std().add_suffix("_sd"))
    return out.reset_index()


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", default=ROOT / "data" / "example", type=Path)
    ap.add_argument("--out", default=ROOT / "results" / "python", type=Path)
    ap.add_argument("--paper-methods", action="store_true",
                    help="use ANOVA/Kruskal-Wallis per plant as in the paper instead of "
                         "choosing by Shapiro-Wilk")
    ap.add_argument("--chl-extract-ml", type=float, default=1.0,
                    help="ethanol extract volume (mL) for Chl a; 1.0 reproduces the paper")
    a = ap.parse_args()

    fig_dir = a.out / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)
    report = []

    def log(text):
        print(text)
        report.append(text)

    # ------------------------------------------------------ 3.1 toxicity
    tox = pd.read_csv(a.data / "toxicity.csv")
    tox["viability_pct"] = eq.cell_viability(tox.sample_od_d0, tox.sample_od_d7,
                                             tox.control_od_d0, tox.control_od_d7,
                                             tox.blank_d0, tox.blank_d7)
    tox.to_csv(a.out / "toxicity_processed.csv", index=False)
    log("=" * 70 + "\n3.1 CELL VIABILITY (toxicity test)\n" + "=" * 70)
    log(st.factorial_anova(tox, "viability_pct ~ C(binder) * C(inoculum)").round(4).to_string())
    tox_letters = {}
    for b, g in tox.groupby("binder", sort=False):
        res = st.compare_groups(g[g.inoculum.isin(CO_RATIOS)], "viability_pct", "inoculum")
        tox_letters[b] = res["letters"]
        log(st.format_result(f"Viability, {b} binder, mixing ratios", res))

    # --------------------------------------------------- 3.2 degradation
    deg = pd.read_csv(a.data / "degradation.csv")
    deg["degradation_pct"] = eq.degradation(deg.dry_weight_d0, deg.dry_weight_d7)
    deg.to_csv(a.out / "degradation_processed.csv", index=False)
    log("=" * 70 + "\n3.2 DEGRADATION OF LIVING BIOFILTERS\n" + "=" * 70)
    deg["degradation_asin"] = eq.arcsine_transform(deg.degradation_pct)
    log(st.factorial_anova(deg, "degradation_asin ~ C(binder) * C(inoculum)").round(4).to_string())
    deg_letters = {}
    for b, g in deg.groupby("binder", sort=False):
        res = st.compare_groups(g[g.inoculum.isin(CO_RATIOS)], "degradation_pct", "inoculum",
                                transform="arcsine")
        deg_letters[b] = res["letters"]
        log(st.format_result(f"Degradation, {b} binder, mixing ratios", res))

    # ------------------------------------------------- decision matrix
    v = tox.groupby(["binder", "inoculum"]).viability_pct.mean()
    d = deg.groupby(["binder", "inoculum"]).degradation_pct.mean()
    dm = pd.concat([v, d], axis=1).reset_index()
    dm = dm[dm.inoculum.isin(CO_RATIOS)].copy()
    dm["score"] = eq.decision_matrix(dm.viability_pct, dm.degradation_pct)
    dm = dm.sort_values("score", ascending=False)
    dm.to_csv(a.out / "decision_matrix.csv", index=False)
    log("Decision matrix (higher score = better binder/ratio):\n" + dm.round(3).to_string(index=False) + "\n")

    tox_sum = tox.groupby(["binder", "inoculum"], sort=False).viability_pct.agg(["mean", "std"])
    tox_sum = tox_sum.rename(columns={"std": "sd"}).reset_index()
    plots.fig_binder_screen(tox_sum, "viability_pct", "% Cell viability", tox_letters,
                            fig_dir / "fig2ab_cell_viability.png")
    deg_sum = deg.groupby(["binder", "inoculum"], sort=False).degradation_pct.agg(["mean", "std"])
    deg_sum = deg_sum.rename(columns={"std": "sd"}).reset_index()
    plots.fig_binder_screen(deg_sum, "degradation_pct", "% Degradation", deg_letters,
                            fig_dir / "fig2ef_degradation.png")

    # ------------------------------------------------- 3.3 nutrients
    nut = pd.read_csv(a.data / "nutrients.csv")
    ci = nut[nut.day == 0].set_index(["ratio", "system", "replicate"])[["nh4_mg_l", "po4_mg_l"]]
    nut = nut.join(ci, on=["ratio", "system", "replicate"], rsuffix="_initial")
    for n in ("nh4", "po4"):
        nut[f"{n}_removal_pct"] = eq.removal_efficiency(nut[f"{n}_mg_l_initial"], nut[f"{n}_mg_l"])
        nut[f"{n}_rate"] = eq.absorption_rate(nut[f"{n}_mg_l_initial"], nut[f"{n}_mg_l"],
                                              nut.volume_l, nut.day, nut.initial_biomass_g)
    nut["group"] = nut.ratio + "_CV/BS_" + nut.system
    nut["subject"] = nut.group + "_r" + nut.replicate.astype(str)
    nut.to_csv(a.out / "nutrients_processed.csv", index=False)
    nut_sum = mean_sd(nut, ["ratio", "system", "day"],
                      ["nh4_removal_pct", "po4_removal_pct", "nh4_rate", "po4_rate"])
    nut_sum.to_csv(a.out / "nutrients_summary.csv", index=False)

    log("=" * 70 + "\n3.3 NUTRIENT REMOVAL\n" + "=" * 70)
    last = nut[nut.day == nut.day.max()]
    for n, lab in (("nh4", "NH4+"), ("po4", "PO4 3-")):
        log(f"Day {int(nut.day.max())} {lab} removal (mean +/- SD):\n"
            + last.groupby("group")[f"{n}_removal_pct"].agg(["mean", "std"]).round(2).to_string())
        res = st.compare_groups(last, f"{n}_removal_pct", "group", method="kruskal")
        log(st.format_result(f"{lab} removal on final day", res))
        rm = nut[nut.day > 0].copy()
        rm[f"{n}_asin"] = eq.arcsine_transform(rm[f"{n}_removal_pct"])
        log(f"Two-way repeated-measures (mixed) ANOVA, {lab} removal (arcsine):\n"
            + st.mixed_anova(rm, f"{n}_asin", "day", "group", "subject").round(4).to_string() + "\n")
    plots.fig_nutrients(nut_sum, fig_dir / "fig3_nutrient_removal.png")

    # ------------------------------------------------- 3.4-3.7 plants
    pl = pd.read_csv(a.data / "plants.csv")
    pl["chl_a_ug_g"] = eq.chlorophyll_a(pl.A630, pl.A645, pl.A663, pl.A750,
                                       pl.dry_biomass_g, a.chl_extract_ml)
    soil = pd.read_csv(a.data / "soil.csv")
    soil["total_n_mg_kg"] = eq.total_n(soil.n_titrant_volume, soil.n_acid_normality, soil.soil_weight_kg)
    soil["total_p_mg_kg"] = eq.total_p(soil.p_conc_mg_ml, soil.p_v_sample, soil.p_acid_molarity,
                                       soil.p_v_naoh, soil.p_v_molybdate, soil.p_dilution_pct,
                                       soil.soil_weight_kg)
    soil["total_k_mg_kg"] = eq.total_k(soil.k_od, soil.soil_weight_kg)
    pl = pl.merge(soil[["plant", "treatment", "replicate", "soil_ph",
                        "total_n_mg_kg", "total_p_mg_kg", "total_k_mg_kg"]],
                  on=["plant", "treatment", "replicate"], how="left")
    pl.to_csv(a.out / "plants_processed.csv", index=False)

    variables = {
        "total_height_cm": "Total plant height (cm)", "leaf_cm": "Leaf (cm)",
        "branch_cm": "Branch (cm)", "stem_cm": "Stem (cm)", "root_cm": "Root (cm)",
        "dry_biomass_g": "Dry biomass (g)", "soil_ph": "Soil pH",
        "chl_a_ug_g": "Chl a (ug/g plant biomass)", "total_n_mg_kg": "Soil total N (mg/kg)",
        "total_p_mg_kg": "Soil total P (mg/kg)", "total_k_mg_kg": "Soil total K (mg/kg)",
    }
    pl_sum = mean_sd(pl, ["plant", "treatment"], list(variables))
    pl_sum.to_csv(a.out / "plants_summary.csv", index=False)

    log("=" * 70 + "\n3.4-3.8 PLANT GROWTH, SOIL pH, CHLOROPHYLL a, SOIL N/P/K\n" + "=" * 70)
    letters, rows = {}, []
    for plant, g in pl.groupby("plant", sort=False):
        method = PAPER_METHOD.get(plant, "auto") if a.paper_methods else "auto"
        for var, lab in variables.items():
            res = st.compare_groups(g, var, "treatment", method=method)
            letters[(plant, var)] = res["letters"]
            log(st.format_result(f"{plant} - {lab}", res))
            rows.append(dict(plant=plant, variable=var, test=res["test"],
                             statistic=res["statistic"], df=str(res["df"]), p=res["p"],
                             **{f"letter_{k}": v for k, v in res["letters"].items()}))
    pd.DataFrame(rows).to_csv(a.out / "plants_statistics.csv", index=False)

    plots.fig_plant_lengths(pl_sum, letters, TREATMENTS, fig_dir / "fig4_plant_lengths.png")
    plots.fig_grid(pl_sum, ["dry_biomass_g", "soil_ph", "chl_a_ug_g"],
                   ["Biomass (g)", "pH values", "Chl a per weight of biomass (ug/g)"],
                   letters, TREATMENTS, fig_dir / "fig5_biomass_ph_chla.png")
    plots.fig_grid(pl_sum, ["total_n_mg_kg", "total_p_mg_kg", "total_k_mg_kg"],
                   ["Total N (mg/kg soil)", "Total P (mg/kg soil)", "Total K (mg/kg soil)"],
                   letters, TREATMENTS, fig_dir / "fig6_soil_npk.png")

    (a.out / "statistics_report.txt").write_text("\n".join(report))
    print(f"\nDone. Results in {a.out}")


if __name__ == "__main__":
    main()
