"""Analysis code for microalgal-bacterial living biofilters (Odibo et al., 2024)."""
from . import equations, stats  # noqa: F401

__version__ = "1.0.0"
