"""Figures in the layout of Figs. 2-6 of the paper (matplotlib)."""
from __future__ import annotations

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

TREATMENT_COLORS = ["#F28030", "#FFC20E", "#6AA84F", "#990000", "#8B6508"]
RATIO_COLORS = {"CV": "#7F7F7F", "BS": "#B0B0B0", "3:1": "#C00000", "1:1": "#FFC000", "1:3": "#548235"}
PLANT_COLORS = {"Morning glory": "#FFC000", "Sunflower": "#C00000", "Cucumber": "#548235"}


def _bar_with_letters(ax, labels, means, sds, colors, letters=None):
    x = np.arange(len(labels))
    ax.bar(x, means, yerr=sds, color=colors, capsize=3, edgecolor="none")
    ax.set_xticks(x, labels, fontsize=8)
    if letters:
        top = np.nanmax(np.asarray(means) + np.asarray(sds))
        for xi, m, s, lab in zip(x, means, sds, labels):
            ax.text(xi, m + s + 0.03 * top, letters.get(lab, ""), ha="center", fontsize=8)
    ax.spines[["top", "right"]].set_visible(False)


def fig_binder_screen(summary, value, ylabel, letters, path):
    """Fig. 2 (a,b) or (e,f): one panel per binder; summary has binder, inoculum, mean, sd."""
    binders = list(summary["binder"].unique())
    fig, axes = plt.subplots(len(binders), 1, figsize=(5.5, 3.2 * len(binders)), sharey=True)
    axes = np.atleast_1d(axes)
    order = ["CV", "BS", "3:1", "1:1", "1:3"]
    for ax, b in zip(axes, binders):
        s = summary[summary["binder"] == b].set_index("inoculum").reindex(order).dropna(how="all")
        _bar_with_letters(ax, list(s.index), s["mean"], s["sd"],
                          [RATIO_COLORS[i] for i in s.index], letters.get(b))
        ax.axvline(1.5, ls="--", color="grey", lw=0.8)
        ax.set_ylabel(ylabel)
        ax.set_title(b, loc="right", fontsize=10)
    axes[-1].set_xlabel("Single culture  |  Mixing ratio (CV/BS)")
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def fig_nutrients(summary, path):
    """Fig. 3: removal efficiency (a,b) and absorption rate (c,d) over time."""
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    styles = {("3:1", "I"): ("#C00000", "-", "s"), ("3:1", "S"): ("#C00000", "--", "s"),
              ("1:1", "I"): ("#2E75B6", "-", "o"), ("1:1", "S"): ("#2E75B6", "--", "o")}
    panels = [("nh4_removal_pct", "% NH$_4^+$ removal efficiency", "a"),
              ("po4_removal_pct", "% PO$_4^{3-}$ removal efficiency", "b"),
              ("nh4_rate", "NH$_4^+$ absorption rate (mg day$^{-1}$ g$^{-1}$)", "c"),
              ("po4_rate", "PO$_4^{3-}$ absorption rate (mg day$^{-1}$ g$^{-1}$)", "d")]
    for ax, (col, ylab, tag) in zip(axes.flat, panels):
        for (ratio, system), (c, ls, mk) in styles.items():
            s = summary[(summary.ratio == ratio) & (summary.system == system)].sort_values("day")
            if col.endswith("rate"):
                s = s[s.day > 0]
            ax.errorbar(s.day, s[f"{col}_mean"], yerr=s[f"{col}_sd"], color=c, ls=ls,
                        marker=mk, mfc=c if system == "I" else "white", capsize=2,
                        label=f"{ratio}_CV/BS_{system}")
        ax.set_xlabel("Time (Day)")
        ax.set_ylabel(ylab)
        ax.set_title(f"({tag})", loc="left", fontsize=10)
        ax.legend(fontsize=8, frameon=False, loc="best")
        ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def fig_plant_lengths(summary, letters, treatments, path):
    """Fig. 4: grouped bars of plant-part lengths, one panel per plant."""
    parts = ["total_height_cm", "leaf_cm", "branch_cm", "stem_cm", "root_cm"]
    part_names = ["Total plant growth", "Leaf", "Branch", "Stem", "Root"]
    plants = list(summary["plant"].unique())
    fig, axes = plt.subplots(len(plants), 1, figsize=(10, 3.6 * len(plants)))
    w = 0.8 / len(treatments)
    for ax, plant, tag in zip(np.atleast_1d(axes), plants, "abc"):
        s = summary[summary.plant == plant].set_index("treatment")
        for i, (trt, col) in enumerate(zip(treatments, TREATMENT_COLORS)):
            x = np.arange(len(parts)) + (i - (len(treatments) - 1) / 2) * w
            m = [s.loc[trt, f"{p}_mean"] for p in parts]
            sd = [s.loc[trt, f"{p}_sd"] for p in parts]
            ax.bar(x, m, w, yerr=sd, color=col, capsize=2, label=trt)
            for xi, mi, si, p in zip(x, m, sd, parts):
                lab = letters.get((plant, p), {}).get(trt, "")
                ax.text(xi, mi + si + 0.3, lab, ha="center", fontsize=7)
        ax.set_xticks(np.arange(len(parts)), part_names)
        ax.set_ylabel("Plant length (cm)")
        ax.set_title(f"({tag}) {plant}", loc="right", fontsize=10)
        ax.legend(fontsize=7, frameon=False, ncol=1, loc="upper center")
        ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def fig_grid(summary, variables, ylabels, letters, treatments, path):
    """Figs. 5 and 6: 3 x 3 grid, rows = variables, columns = plants (as in the paper)."""
    plants = list(summary["plant"].unique())
    fig, axes = plt.subplots(len(plants), len(variables),
                             figsize=(4.2 * len(variables), 3.0 * len(plants)))
    short = ["Control", "Chemical\nfertilizer", "Biofilter\n(CV/BS 3:1)",
             "Biofilter\n(CV/BS 1:1)", "Biofilter\ncontrol"]
    tags = iter("abcdefghi")
    for j, (var, ylab) in enumerate(zip(variables, ylabels)):
        for i, plant in enumerate(plants):
            ax = axes[i, j]
            s = summary[summary.plant == plant].set_index("treatment").reindex(treatments)
            lt = {sh: letters.get((plant, var), {}).get(t, "") for sh, t in zip(short, treatments)}
            _bar_with_letters(ax, short, s[f"{var}_mean"], s[f"{var}_sd"],
                              [PLANT_COLORS[plant]] * len(treatments), lt)
            ax.tick_params(axis="x", labelsize=6)
            ax.set_ylabel(ylab, fontsize=8)
            ax.set_title(f"({next(tags)}) {plant}", loc="right", fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)
