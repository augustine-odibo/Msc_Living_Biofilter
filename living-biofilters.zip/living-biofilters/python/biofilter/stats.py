"""
Statistical workflow from Section 2.13 of the paper:

* percentage data -> arcsine transform
* Shapiro-Wilk normality test
* normal      -> one-way ANOVA + Tukey HSD
* non-normal  -> Kruskal-Wallis + pairwise Mann-Whitney U
* multi-factor ANOVA for toxicity / degradation
* mixed (repeated-measures) ANOVA for the 7-day nutrient removal trials
"""
from __future__ import annotations

from itertools import combinations

import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm
from statsmodels.stats.multicomp import pairwise_tukeyhsd

ALPHA = 0.05


def is_normal(df, value, group, alpha=ALPHA):
    """True if every group passes Shapiro-Wilk (groups with n < 3 are skipped)."""
    for _, g in df.groupby(group, observed=True):
        x = g[value].dropna()
        if len(x) >= 3 and np.ptp(x) > 0:
            if stats.shapiro(x).pvalue < alpha:
                return False
    return True


def compact_letters(groups, pvals, alpha=ALPHA):
    """Compact letter display: groups sharing a letter are not significantly different.

    groups : ordered list of group names
    pvals  : dict {(g1, g2): p} for each pair
    """
    def p_of(a, b):
        return pvals.get((a, b), pvals.get((b, a), 1.0))

    # insert-and-absorb algorithm (Piepho 2004)
    letter_sets = [set(groups)]
    for a, b in combinations(groups, 2):
        if p_of(a, b) >= alpha:
            continue
        new_sets = []
        for s in letter_sets:
            if a in s and b in s:
                new_sets.append(s - {a})
                new_sets.append(s - {b})
            else:
                new_sets.append(s)
        # absorb: drop sets that are subsets of another set
        new_sets = [s for i, s in enumerate(new_sets)
                    if not any(s < t or (s == t and j < i)
                               for j, t in enumerate(new_sets) if j != i)]
        letter_sets = new_sets

    # order letters by first group they appear in
    letter_sets.sort(key=lambda s: min(groups.index(g) for g in s))
    out = {g: "" for g in groups}
    for i, s in enumerate(letter_sets):
        for g in s:
            out[g] += "abcdefghijklmnopqrstuvwxyz"[i]
    return out


def compare_groups(df, value, group, method="auto", transform=None, alpha=ALPHA):
    """One-factor comparison across groups.

    method    : "auto" (pick by normality), "anova" or "kruskal"
    transform : None or "arcsine" (for % data)
    Returns a dict with test name, statistic, df, p, pairwise table and letters.
    """
    from .equations import arcsine_transform

    d = df[[group, value]].dropna().copy()
    if transform == "arcsine":
        d[value] = arcsine_transform(d[value])

    groups = list(pd.unique(d[group]))
    samples = [d.loc[d[group] == g, value].values for g in groups]

    if method == "auto":
        method = "anova" if is_normal(d, value, group, alpha) else "kruskal"

    pvals = {}
    if method == "anova":
        f, p = stats.f_oneway(*samples)
        stat_name, dfree = "F", (len(groups) - 1, len(d) - len(groups))
        tk = pairwise_tukeyhsd(d[value], d[group], alpha=alpha)
        tab = pd.DataFrame(tk.summary().data[1:], columns=tk.summary().data[0])
        for _, r in tab.iterrows():
            pvals[(r["group1"], r["group2"])] = float(r["p-adj"])
        pairwise = tab
        test = "One-way ANOVA + Tukey HSD"
        statistic = f
    else:
        h, p = stats.kruskal(*samples)
        stat_name, dfree = "H", len(groups) - 1
        rows = []
        for (ga, xa), (gb, xb) in combinations(zip(groups, samples), 2):
            u, pu = stats.mannwhitneyu(xa, xb, alternative="two-sided")
            pvals[(ga, gb)] = pu
            rows.append({"group1": ga, "group2": gb, "U": u, "p": pu})
        pairwise = pd.DataFrame(rows)
        test = "Kruskal-Wallis + pairwise Mann-Whitney U"
        statistic = h

    return {
        "test": test,
        "stat_name": stat_name,
        "statistic": float(statistic),
        "df": dfree,
        "p": float(p),
        "pairwise": pairwise,
        "letters": compact_letters(groups, pvals, alpha),
    }


def factorial_anova(df, formula):
    """Multi-factor ANOVA (Type II), e.g. 'viability ~ C(binder) * C(inoculum)'."""
    model = smf.ols(formula, data=df).fit()
    return anova_lm(model, typ=2)


def mixed_anova(df, dv, within, between, subject):
    """Two-way repeated-measures (mixed) ANOVA: time (within) x group (between)."""
    import pingouin as pg
    return pg.mixed_anova(data=df, dv=dv, within=within, between=between,
                          subject=subject)


def format_result(name, res):
    """Readable one-line summary + letters."""
    dfs = res["df"] if isinstance(res["df"], int) else f"{res['df'][0]}, {res['df'][1]}"
    sig = "significant" if res["p"] < ALPHA else "not significant"
    letters = ", ".join(f"{k}: {v}" for k, v in res["letters"].items())
    return (f"{name}\n  {res['test']}: {res['stat_name']} = {res['statistic']:.3f}, "
            f"DF = {dfs}, P = {res['p']:.4f} ({sig})\n  Letters -> {letters}\n")
