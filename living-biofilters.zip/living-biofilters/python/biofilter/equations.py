"""
Equations from Odibo et al. (2024), Bioresource Technology 398, 130509.
https://doi.org/10.1016/j.biortech.2024.130509

Every function accepts scalars, NumPy arrays or pandas Series, so they can be
applied column-wise to a DataFrame.
"""
from __future__ import annotations

import numpy as np

# --------------------------------------------------------------------------
# 2.3 Toxicity test - % cell viability
# --------------------------------------------------------------------------
def cell_viability(sample_od_d0, sample_od_d7, control_od_d0, control_od_d7,
                   blank_d0=0.0, blank_d7=0.0):
    """% cell viability (OD750), adapted from He et al. (2006).

    viability = [(S7 - blank7) - (S0 - blank0)] / [(C7 - blank7) - (C0 - blank0)] x 100
    """
    sample_growth = (sample_od_d7 - blank_d7) - (sample_od_d0 - blank_d0)
    control_growth = (control_od_d7 - blank_d7) - (control_od_d0 - blank_d0)
    return sample_growth / control_growth * 100.0


# --------------------------------------------------------------------------
# 2.4 Degradation test
# --------------------------------------------------------------------------
def degradation(dry_weight_d0, dry_weight_d7):
    """% degradation = (W0 - W7) / W0 x 100"""
    return (dry_weight_d0 - dry_weight_d7) / dry_weight_d0 * 100.0


# --------------------------------------------------------------------------
# 2.5 Nutrient removal
# --------------------------------------------------------------------------
def removal_efficiency(c_initial, c_final):
    """% nutrient removal efficiency = (Ci - Cf) / Ci x 100"""
    return (c_initial - c_final) / c_initial * 100.0


def absorption_rate(c_initial, c_final, volume_l, time_day, biomass_g):
    """Nutrient absorption rate (mg day^-1 g_biomass^-1)

    rate = (Ci - Cf) x V / (T x m)
    Ci, Cf : mg/L   V : working volume (L)   T : days   m : initial dry biomass (g)
    """
    time_day = np.asarray(time_day, dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        rate = (c_initial - c_final) * volume_l / (time_day * biomass_g)
    return np.where(time_day > 0, rate, np.nan)


# --------------------------------------------------------------------------
# 2.10 Chlorophyll a per dried plant biomass (modified Sartory & Grobbelaar 1984)
# --------------------------------------------------------------------------
def chlorophyll_a(a630, a645, a663, a750, dry_weight_g, extract_volume_ml=1.0):
    """Chl a per dried plant biomass (ug / g).

    Chl a = [11.62(A663-A750) - 2.16(A645-A750) - 0.1(A630-A750)] / dry weight

    The bracket gives ug/mL of extract. The paper divides it directly by dry
    weight (extract_volume_ml = 1). Pass the real extract volume (e.g. 1.5 mL)
    to convert to ug of chlorophyll per g of biomass.
    """
    conc = (11.62 * (a663 - a750)
            - 2.16 * (a645 - a750)
            - 0.10 * (a630 - a750))
    return conc * extract_volume_ml / dry_weight_g


# --------------------------------------------------------------------------
# 2.12 Soil N, P, K
# --------------------------------------------------------------------------
def total_n(titrant_volume, acid_normality, soil_weight_kg):
    """Kjeldahl total N (mg/kg) = V x N x 14.01 x 100 / W"""
    return titrant_volume * acid_normality * 14.01 * 100.0 / soil_weight_kg


def total_p(p_conc_mg_ml, v_sample, acid_molarity, v_naoh, v_molybdate,
            dilution_pct, soil_weight_kg):
    """Alkaline-oxidation total P (mg/kg)

    = C x (V1/M) x (V2/V3) x 1000 / ((100 - H) x W)
    """
    return (p_conc_mg_ml * (v_sample / acid_molarity) * (v_naoh / v_molybdate)
            * 1000.0 / ((100.0 - dilution_pct) * soil_weight_kg))


def total_k(od_k, soil_weight_kg, standard_conc=100.0):
    """Flame-photometer total K (mg/kg) = OD x 1.2 x 100 / W"""
    return od_k * 1.2 * standard_conc / soil_weight_kg


# --------------------------------------------------------------------------
# 2.13 Transform used on percentage data before statistics
# --------------------------------------------------------------------------
def arcsine_transform(percent):
    """asin(sqrt(p)) with p as a proportion; values clipped to [0, 1].

    Viability can exceed 100 %, so values are clipped before transforming.
    """
    p = np.clip(np.asarray(percent, dtype=float) / 100.0, 0.0, 1.0)
    return np.arcsin(np.sqrt(p))


# --------------------------------------------------------------------------
# 2.4 Decision matrix used to pick the binder / ratio
# --------------------------------------------------------------------------
def decision_matrix(viability, degradation_pct, w_viability=0.5, w_degradation=0.5):
    """Score conditions: high viability is good, low degradation is good.

    Each criterion is min-max scaled to 0-1, then combined with the weights.
    Returns scores in the input order (higher is better).
    """
    v = np.asarray(viability, dtype=float)
    d = np.asarray(degradation_pct, dtype=float)

    def scale(x):
        rng = np.ptp(x)
        return np.zeros_like(x) if rng == 0 else (x - x.min()) / rng

    return w_viability * scale(v) + w_degradation * (1.0 - scale(d))
