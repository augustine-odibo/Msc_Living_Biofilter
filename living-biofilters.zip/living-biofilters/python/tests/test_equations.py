"""Checks the equations against values reported in Odibo et al. (2024).

    pytest python/tests
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from biofilter import equations as eq  # noqa: E402
from biofilter import stats as st  # noqa: E402


def test_removal_efficiency_reported_values():
    # 86.7 % NH4+ removal from 67.1 mg/L leaves 8.93 mg/L
    assert eq.removal_efficiency(67.1, 67.1 * (1 - 0.867)) == pytest.approx(86.7)


def test_absorption_rate_matches_fig3_day1():
    # Fig. 3c/d: 1:1 living biofilter, day 1, 50 mL, ~0.1 g biomass
    nh4 = eq.absorption_rate(67.1, 67.1 * (1 - 0.56), 0.05, 1, 0.1)
    po4 = eq.absorption_rate(29.9, 29.9 * (1 - 0.58), 0.05, 1, 0.1)
    assert float(nh4) == pytest.approx(18.7, abs=0.2)
    assert float(po4) == pytest.approx(8.7, abs=0.1)


def test_absorption_rate_day0_is_nan():
    assert np.isnan(eq.absorption_rate(67.1, 67.1, 0.05, 0, 0.1))


def test_viability_equal_growth_is_100():
    assert eq.cell_viability(0.8, 1.2, 0.8, 1.2, 0.05, 0.05) == pytest.approx(100)


def test_degradation():
    assert eq.degradation(0.200, 0.194) == pytest.approx(3.0)


def test_chlorophyll_a():
    # only A663 above baseline -> 11.62 * dA / dry weight
    assert eq.chlorophyll_a(0.01, 0.01, 1.01, 0.01, 2.0) == pytest.approx(5.81)


def test_soil_npk():
    assert eq.total_n(1.0, 0.01, 0.015) == pytest.approx(1.0 * 0.01 * 1401 / 0.015)
    assert eq.total_k(0.5, 0.015) == pytest.approx(0.5 * 120 / 0.015)
    assert eq.total_p(1, 3, 1, 20, 2, 0, 1) == pytest.approx(300)


def test_arcsine_clips():
    assert eq.arcsine_transform(150) == pytest.approx(np.pi / 2)
    assert eq.arcsine_transform(0) == 0


def test_decision_matrix_prefers_high_viability_low_degradation():
    s = eq.decision_matrix([219, 110, 52], [3.0, 5.3, 4.1])
    assert np.argmax(s) == 0


def test_kruskal_reproduces_paper_H():
    # 4 fully separated groups of n = 3 give H = 10.38, DF = 3 (Section 3.3)
    df = pd.DataFrame({"g": np.repeat(list("ABCD"), 3),
                       "v": [86, 87, 86.5, 81, 82, 80, 54, 55, 54.5, 50, 49, 50.5]})
    res = st.compare_groups(df, "v", "g", method="kruskal")
    assert res["statistic"] == pytest.approx(10.38, abs=0.01)
    assert res["df"] == 3


def test_compact_letters():
    pv = {("A", "B"): 0.9, ("A", "C"): 0.001, ("B", "C"): 0.001}
    assert st.compact_letters(["A", "B", "C"], pv) == {"A": "a", "B": "a", "C": "b"}
