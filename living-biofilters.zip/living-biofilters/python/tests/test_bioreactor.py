"""Checks for the kinetic bioreactor model.

    pytest python/tests
"""
import sys
from dataclasses import replace
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from bioreactor.model import Params, Reactor, simulate  # noqa: E402


@pytest.fixture(scope="module")
def run():
    p = replace(Params(), b_a=0.0, b_b=0.0)          # no decay -> closed N and P balances
    r = Reactor.wastewater("immobilized", 0.1, 0.5)
    return p, r, simulate(p, r, t_end=3.0)


def test_nitrogen_mass_balance(run):
    p, r, o = run
    total = o["N"] * r.V_L + (p.i_N_a * o["Xa"] + p.i_N_b * o["Xb"]) * 1000 + o["SN"]
    assert np.allclose(total, total[0], rtol=1e-3)


def test_phosphorus_mass_balance(run):
    p, r, o = run
    total = o["P"] * r.V_L + (o["Qp"] * o["Xa"] + p.i_P_b * o["Xb"]) * 1000 + o["SP"]
    assert np.allclose(total, total[0], rtol=1e-3)


def test_no_growth_in_the_dark():
    p = replace(Params(), light_fraction=0.0, mu_max_b=0.0, b_a=0.0, q_max_N=0.0, q_max_P=0.0)
    o = simulate(p, Reactor.wastewater("suspended", 0.1, 1.0), t_end=2.0)
    assert o["Xa"][-1] == pytest.approx(o["Xa"][0])


def test_removal_starts_at_zero_and_stays_physical(run):
    _, _, o = run
    assert o["nh4_removal_pct"][0] == pytest.approx(0)
    assert np.all(o["N"] >= -1e-6) and np.all(o["P"] >= -1e-6)


def test_pbr_grows_in_bg11():
    o = simulate(Params(q_max_N=0, q_max_P=0), Reactor.bg11_pbr(), t_end=7.0)
    assert o["Xa_g_l"][-1] > 2 * o["Xa_g_l"][0]
