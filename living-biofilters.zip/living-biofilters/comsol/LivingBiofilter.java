/*
 * COMSOL Multiphysics model of the living biofilter in the wastewater bottle
 * (Odibo et al., 2024, Bioresource Technology 398, 130509).
 *
 * 2D cross-section of the 50 mL treatment bottle as a unit cell that is as wide
 * as the textile (4 cm) and 8 cm deep out of plane:
 *
 *      y ^   +------------------------------+  y = t_b + H_L   (light from above)
 *        |   |  wastewater (50 mL), shaken   |  D = D_mix (effective mixing)
 *        |   +------------------------------+  y = t_b
 *        |   |  gel + cells on cotton (1 mm) |  D = f_gel * D_molecular, reactions
 *        +---+------------------------------+--> x      (W_t = 4 cm)
 *
 * Physics
 *   tds  : Transport of Diluted Species (whole geometry) - NH4+ (cN), PO4 3- (cP),
 *          glucose (cG), O2 (cO). Uptake reactions in the biofilter; O2 gas
 *          exchange (k_La) in the liquid.
 *   tds2 : Transport of Diluted Species (biofilter only, non-diffusing) - algae (Xa),
 *          bacteria (Xb), algal P content (PA), sorbed N (SN), sorbed P (SP).
 *
 * Kinetics are the same as python/bioreactor/model.py: Monod-Droop algae with
 * depth-dependent light (Beer-Lambert inside the gel) and a 12:12 h photoperiod,
 * Monod bacteria on glucose/O2/N/P, luxury P uptake and a fast sorption stage.
 * Parameter values come from parameters_fitted.txt (written by
 * python/run_bioreactor.py); the values below are fallbacks.
 *
 * Build and run (COMSOL 6.x):
 *   comsolcompile LivingBiofilter.java
 *   comsolbatch -inputfile LivingBiofilter.class -outputfile living_biofilter.mph
 * Then open living_biofilter.mph in COMSOL Desktop.
 */
import com.comsol.model.*;
import com.comsol.model.util.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class LivingBiofilter {

  /** Reads lines of the form:  name expression "description"  into the global parameters. */
  static void loadParameterFile(Model model, String path) {
    File f = new File(path);
    if (!f.exists()) {
      System.out.println("No " + path + " found - using built-in parameter values.");
      return;
    }
    try (BufferedReader br = new BufferedReader(new FileReader(f))) {
      String line;
      while ((line = br.readLine()) != null) {
        line = line.trim();
        if (line.isEmpty() || line.startsWith("#")) continue;
        String[] head = line.split("\\s+", 3);
        if (head.length < 2) continue;
        String descr = head.length == 3 ? head[2].replace("\"", "") : "";
        model.param().set(head[0], head[1], descr);
      }
      System.out.println("Loaded parameters from " + path);
    } catch (Exception e) {
      System.out.println("Could not read " + path + ": " + e.getMessage());
    }
  }

  public static Model run() {
    Model model = ModelUtil.create("Model");
    model.label("living_biofilter.mph");
    model.comments("Living biofilter (C. vulgaris + B. subtilis in GG/CG gel on cotton) "
        + "treating 50 mL synthetic wastewater for 7 days. Odibo et al. 2024.");

    // ------------------------------------------------------------------ parameters
    // geometry and operation (Sections 2.2 and 2.5)
    model.param().set("W_t", "4[cm]", "Textile width (2D cross-section)");
    model.param().set("L_t", "8[cm]", "Textile length (out of plane)");
    model.param().set("t_b", "1[mm]", "Gel + cell layer thickness (assumed)");
    model.param().set("V_L", "50[ml]", "Wastewater working volume");
    model.param().set("H_L", "V_L/(W_t*L_t)", "Liquid height above the biofilter");
    model.param().set("V_bf", "W_t*L_t*t_b", "Biofilter volume");
    model.param().set("m_bio", "0.1[g]", "Initial dry biomass on the biofilter");
    model.param().set("f_algae", "0.5", "Algae fraction of biomass (0.5 = CV/BS 1:1, 0.75 = 3:1)");
    model.param().set("Q0", "0.01", "Initial algal P quota (g P/g)");
    // initial wastewater (Section 2.5)
    model.param().set("C_NH4_0", "67.1[g/m^3]", "Initial NH4+ (mg/L)");
    model.param().set("C_PO4_0", "29.9[g/m^3]", "Initial PO4 3- (mg/L)");
    model.param().set("C_G_0", "450[g/m^3]", "Initial glucose (mg/L)");
    // molar masses
    model.param().set("M_NH4", "18.038[g/mol]", "");
    model.param().set("M_PO4", "94.971[g/mol]", "");
    model.param().set("M_N", "14.007[g/mol]", "");
    model.param().set("M_P", "30.974[g/mol]", "");
    model.param().set("M_G", "180.16[g/mol]", "Glucose");
    model.param().set("M_O2", "31.998[g/mol]", "");
    model.param().set("M_X", "24.6[g/mol]", "Biomass, per C-mol (CH1.8O0.5N0.2)");
    model.param().set("cN0", "C_NH4_0/M_NH4", "");
    model.param().set("cP0", "C_PO4_0/M_PO4", "");
    model.param().set("cG0", "C_G_0/M_G", "");
    model.param().set("cO0", "O_sat/M_O2", "");
    model.param().set("Xa0", "m_bio*f_algae/V_bf/M_X", "Initial algae (C-mol/m3 gel)");
    model.param().set("Xb0", "m_bio*(1-f_algae)/V_bf/M_X", "Initial bacteria (C-mol/m3 gel)");
    model.param().set("PA0", "Q0*Xa0*M_X/M_P", "Initial algal P (mol P/m3 gel)");
    // transport
    model.param().set("D_mix", "1e-5[m^2/s]", "Effective dispersion in the shaken liquid (40 rpm)");
    model.param().set("f_gel", "0.6", "Diffusivity ratio gel/water");
    model.param().set("D_NH4", "1.96e-9[m^2/s]", "");
    model.param().set("D_PO4", "0.76e-9[m^2/s]", "HPO4 2-");
    model.param().set("D_G", "0.67e-9[m^2/s]", "");
    model.param().set("D_O2", "2.1e-9[m^2/s]", "");
    model.param().set("D_cell", "1e-16[m^2/s]", "Cells do not move (numerical value)");
    // kinetics - fallback values (overwritten by parameters_fitted.txt)
    model.param().set("mu_max_a", "0.198[1/d]", "Algae max growth rate");
    model.param().set("b_a", "0.05[1/d]", "");
    model.param().set("K_Na", "1[g/m^3]", "");
    model.param().set("i_N_a", "0.08", "");
    model.param().set("Q_min", "0.002", "");
    model.param().set("Q_max", "0.03", "");
    model.param().set("rho_max_P", "0.0033[1/d]", "Max P uptake (g P/g algae/d)");
    model.param().set("K_P", "0.5[g/m^3]", "");
    model.param().set("Y_O2_a", "1.3", "");
    model.param().set("I0", "27", "Light at biofilter surface, umol m-2 s-1 (2000 lx)");
    model.param().set("K_I", "20", "Light half-saturation, umol m-2 s-1");
    model.param().set("K_a", "0.15[m^2/g]", "");
    model.param().set("mu_max_b", "0.097[1/d]", "");
    model.param().set("b_b", "0.1[1/d]", "");
    model.param().set("K_G", "20[g/m^3]", "");
    model.param().set("K_O", "0.5[g/m^3]", "");
    model.param().set("K_Nb", "1[g/m^3]", "");
    model.param().set("K_Pb", "0.1[g/m^3]", "");
    model.param().set("Y_G", "0.5", "");
    model.param().set("i_N_b", "0.12", "");
    model.param().set("i_P_b", "0.02", "");
    model.param().set("q_max_N", "0.0070", "Sorption capacity N (g/g)");
    model.param().set("q_max_P", "0.00088", "Sorption capacity P (g/g)");
    model.param().set("K_s", "5[g/m^3]", "");
    model.param().set("k_s", "10[1/d]", "");
    model.param().set("kLa", "5[1/d]", "");
    model.param().set("O_sat", "8.2[g/m^3]", "");
    loadParameterFile(model, "parameters_fitted.txt");

    // -------------------------------------------------------------------- geometry
    model.component().create("comp1", true);
    model.component("comp1").geom().create("geom1", 2);
    model.component("comp1").geom("geom1").create("r1", "Rectangle");
    model.component("comp1").geom("geom1").feature("r1").label("Living biofilter");
    model.component("comp1").geom("geom1").feature("r1").set("pos", new String[]{"0", "0"});
    model.component("comp1").geom("geom1").feature("r1").set("size", new String[]{"W_t", "t_b"});
    model.component("comp1").geom("geom1").feature("r1").set("selresult", true);
    model.component("comp1").geom("geom1").create("r2", "Rectangle");
    model.component("comp1").geom("geom1").feature("r2").label("Wastewater");
    model.component("comp1").geom("geom1").feature("r2").set("pos", new String[]{"0", "t_b"});
    model.component("comp1").geom("geom1").feature("r2").set("size", new String[]{"W_t", "H_L"});
    model.component("comp1").geom("geom1").feature("r2").set("selresult", true);
    model.component("comp1").geom("geom1").run();
    // named selections created by the rectangles: geom1_r1_dom (biofilter), geom1_r2_dom (liquid)

    // ------------------------------------------------------------------- operators
    model.component("comp1").cpl().create("aveop1", "Average");
    model.component("comp1").cpl("aveop1").selection().named("geom1_r2_dom");
    model.component("comp1").cpl().create("intop1", "Integration");
    model.component("comp1").cpl("intop1").selection().named("geom1_r1_dom");

    // ------------------------------------------------------------------- variables
    model.component("comp1").variable().create("var1");
    model.component("comp1").variable("var1").label("Biofilter kinetics");
    model.component("comp1").variable("var1").selection().geom("geom1", 2);
    model.component("comp1").variable("var1").selection().named("geom1_r1_dom");
    String[][] v = {
        {"Xa_g", "max(Xa,0)*M_X", "Algae (g/m3 gel)"},
        {"Xb_g", "max(Xb,0)*M_X", "Bacteria (g/m3 gel)"},
        {"N_g", "max(cN,0)*M_N", "Ammonium-N (g/m3)"},
        {"P_g", "max(cP,0)*M_P", "Phosphate-P (g/m3)"},
        {"G_g", "max(cG,0)*M_G", "Glucose (g/m3)"},
        {"O_g", "max(cO,0)*M_O2", "O2 (g/m3)"},
        {"Qp", "max(max(PA,0)*M_P/max(Xa_g,1e-6[g/m^3]), Q_min*1.0001)", "Algal P quota (g/g)"},
        {"photo", "0.5*(1+tanh(sin(2*pi*t/1[d])/0.05))", "12:12 h photoperiod (smoothed)"},
        {"I_loc", "I0*exp(-K_a*Xa_g*(t_b-y))", "Local light in the gel"},
        {"f_I", "photo*I_loc/(K_I+I_loc)", "Light limitation"},
        {"mu_a", "mu_max_a*f_I*N_g/(K_Na+N_g)*(1-Q_min/Qp)", "Algae growth rate"},
        {"rho_P", "rho_max_P*P_g/(K_P+P_g)*max(Q_max-Qp,0)/(Q_max-Q_min)", "Luxury P uptake"},
        {"mu_b", "mu_max_b*G_g/(K_G+G_g)*O_g/(K_O+O_g)*N_g/(K_Nb+N_g)*P_g/(K_Pb+P_g)", "Bacteria growth rate"},
        {"g_a", "mu_a*Xa_g", "Algae growth (g/m3/s)"},
        {"g_b", "mu_b*Xb_g", "Bacteria growth (g/m3/s)"},
        {"r_SN", "k_s*(q_max_N*(Xa_g+Xb_g)*N_g/(K_s+N_g) - max(SN,0)*M_N)", "N sorption (g/m3/s)"},
        {"r_SP", "k_s*(q_max_P*(Xa_g+Xb_g)*P_g/(K_s+P_g) - max(SP,0)*M_P)", "P sorption (g/m3/s)"},
    };
    for (String[] row : v) {
      model.component("comp1").variable("var1").set(row[0], row[1], row[2]);
    }

    // ------------------------------------------------- physics 1: dissolved species
    model.component("comp1").physics().create("tds", "DilutedSpecies", "geom1");
    model.component("comp1").physics("tds").label("Dissolved species");
    model.component("comp1").physics("tds").field("concentration")
        .component(new String[]{"cN", "cP", "cG", "cO"});
    String[] sp = {"cN", "cP", "cG", "cO"};
    String[] dLiq = {"D_mix", "D_mix", "D_mix", "D_mix"};
    String[] dGel = {"f_gel*D_NH4", "f_gel*D_PO4", "f_gel*D_G", "f_gel*D_O2"};
    for (int i = 0; i < sp.length; i++) {
      model.component("comp1").physics("tds").feature("cdm1")
          .set("D_" + sp[i], iso(dLiq[i]));
    }
    model.component("comp1").physics("tds").create("cdm2", "TransportProperties", 2);
    model.component("comp1").physics("tds").feature("cdm2").label("Transport in gel");
    model.component("comp1").physics("tds").feature("cdm2").selection().named("geom1_r1_dom");
    for (int i = 0; i < sp.length; i++) {
      model.component("comp1").physics("tds").feature("cdm2")
          .set("D_" + sp[i], iso(dGel[i]));
    }
    model.component("comp1").physics("tds").feature("init1").setIndex("initc", "cN0", 0);
    model.component("comp1").physics("tds").feature("init1").setIndex("initc", "cP0", 1);
    model.component("comp1").physics("tds").feature("init1").setIndex("initc", "cG0", 2);
    model.component("comp1").physics("tds").feature("init1").setIndex("initc", "cO0", 3);

    model.component("comp1").physics("tds").create("reac1", "Reactions", 2);
    model.component("comp1").physics("tds").feature("reac1").label("Uptake by living biofilter");
    model.component("comp1").physics("tds").feature("reac1").selection().named("geom1_r1_dom");
    model.component("comp1").physics("tds").feature("reac1")
        .set("R_cN", "-(i_N_a*g_a + i_N_b*g_b + r_SN)/M_N");
    model.component("comp1").physics("tds").feature("reac1")
        .set("R_cP", "-(rho_P*Xa_g + i_P_b*g_b + r_SP)/M_P");
    model.component("comp1").physics("tds").feature("reac1")
        .set("R_cG", "-(g_b/Y_G)/M_G");
    model.component("comp1").physics("tds").feature("reac1")
        .set("R_cO", "(Y_O2_a*g_a - g_b*(1-Y_G)/Y_G*1.07)/M_O2");

    model.component("comp1").physics("tds").create("reac2", "Reactions", 2);
    model.component("comp1").physics("tds").feature("reac2").label("O2 gas exchange (headspace)");
    model.component("comp1").physics("tds").feature("reac2").selection().named("geom1_r2_dom");
    model.component("comp1").physics("tds").feature("reac2")
        .set("R_cO", "kLa*(O_sat/M_O2 - cO)");

    // ---------------------------------------------- physics 2: immobilized biomass
    model.component("comp1").physics().create("tds2", "DilutedSpecies", "geom1");
    model.component("comp1").physics("tds2").label("Immobilized biomass");
    model.component("comp1").physics("tds2").selection().named("geom1_r1_dom");
    model.component("comp1").physics("tds2").field("concentration")
        .component(new String[]{"Xa", "Xb", "PA", "SN", "SP"});
    String[] bio = {"Xa", "Xb", "PA", "SN", "SP"};
    String[] bio0 = {"Xa0", "Xb0", "PA0", "0", "0"};
    for (int i = 0; i < bio.length; i++) {
      model.component("comp1").physics("tds2").feature("cdm1").set("D_" + bio[i], iso("D_cell"));
      model.component("comp1").physics("tds2").feature("init1").setIndex("initc", bio0[i], i);
    }
    model.component("comp1").physics("tds2").create("reac1", "Reactions", 2);
    model.component("comp1").physics("tds2").feature("reac1").selection().named("geom1_r1_dom");
    model.component("comp1").physics("tds2").feature("reac1").set("R_Xa", "(g_a - b_a*Xa_g)/M_X");
    model.component("comp1").physics("tds2").feature("reac1").set("R_Xb", "(g_b - b_b*Xb_g)/M_X");
    model.component("comp1").physics("tds2").feature("reac1").set("R_PA", "rho_P*Xa_g/M_P - b_a*max(PA,0)");
    model.component("comp1").physics("tds2").feature("reac1").set("R_SN", "r_SN/M_N");
    model.component("comp1").physics("tds2").feature("reac1").set("R_SP", "r_SP/M_P");

    // ------------------------------------------------------------------------ mesh
    model.component("comp1").mesh().create("mesh1");
    model.component("comp1").mesh("mesh1").create("ftri1", "FreeTri");
    model.component("comp1").mesh("mesh1").feature("ftri1").create("size1", "Size");
    model.component("comp1").mesh("mesh1").feature("ftri1").feature("size1")
        .selection().geom("geom1", 2);
    model.component("comp1").mesh("mesh1").feature("ftri1").feature("size1")
        .selection().named("geom1_r1_dom");
    model.component("comp1").mesh("mesh1").feature("ftri1").feature("size1").set("custom", "on");
    model.component("comp1").mesh("mesh1").feature("ftri1").feature("size1").set("hmaxactive", true);
    model.component("comp1").mesh("mesh1").feature("ftri1").feature("size1").set("hmax", "t_b/6");
    model.component("comp1").mesh("mesh1").run();

    // ----------------------------------------------------------------------- study
    model.study().create("std1");
    model.study("std1").create("time", "Transient");
    model.study("std1").feature("time").set("tunit", "d");
    model.study("std1").feature("time").set("tlist", "range(0,1/24,7)");
    model.study("std1").createAutoSequences("all");
    model.sol("sol1").runAll();

    // --------------------------------------------------------------------- results
    String[] gExpr = {
        "100*(1-aveop1(cN)/cN0)", "100*(1-aveop1(cP)/cP0)",
        "aveop1(cO)*M_O2", "intop1(Xa)*M_X*L_t", "intop1(Xb)*M_X*L_t"};
    String[] gDescr = {
        "NH4+ removal (%)", "PO4 3- removal (%)", "Mean dissolved O2 in liquid (g/m3)",
        "Algal biomass (g)", "Bacterial biomass (g)"};

    model.result().create("pg1", "PlotGroup1D");
    model.result("pg1").label("Nutrient removal (compare with Fig. 3a,b)");
    model.result("pg1").set("data", "dset1");
    model.result("pg1").create("glob1", "Global");
    model.result("pg1").feature("glob1").set("expr", new String[]{gExpr[0], gExpr[1]});
    model.result("pg1").feature("glob1").set("descr", new String[]{gDescr[0], gDescr[1]});
    model.result("pg1").run();

    model.result().create("pg2", "PlotGroup2D");
    model.result("pg2").label("Dissolved O2");
    model.result("pg2").set("data", "dset1");
    model.result("pg2").create("surf1", "Surface");
    model.result("pg2").feature("surf1").set("expr", "cO*M_O2");
    model.result("pg2").run();

    model.result().create("pg3", "PlotGroup2D");
    model.result("pg3").label("Ammonium");
    model.result("pg3").set("data", "dset1");
    model.result("pg3").create("surf1", "Surface");
    model.result("pg3").feature("surf1").set("expr", "cN*M_NH4");
    model.result("pg3").run();

    model.result().numerical().create("gev1", "EvalGlobal");
    model.result().numerical("gev1").set("data", "dset1");
    model.result().numerical("gev1").set("expr", gExpr);
    model.result().numerical("gev1").set("descr", gDescr);
    model.result().table().create("tbl1", "Table");
    model.result().numerical("gev1").set("table", "tbl1");
    model.result().numerical("gev1").setResult();
    model.result().export().create("exp1", "Table");
    model.result().export("exp1").set("table", "tbl1");
    model.result().export("exp1").set("filename", "comsol_removal_vs_time.csv");
    model.result().export("exp1").run();

    return model;
  }

  /** Isotropic 2D diffusion tensor written as the 3x3 list COMSOL expects. */
  static String[] iso(String d) {
    return new String[]{d, "0", "0", "0", d, "0", "0", "0", d};
  }

  public static void main(String[] args) {
    Model model = run();
    try {
      model.save("living_biofilter.mph");
    } catch (Exception e) {
      System.out.println("Save from comsolbatch with -outputfile instead: " + e.getMessage());
    }
  }
}
