"""
1D preview of the COMSOL model (no COMSOL licence needed).

Solves the same equations as LivingBiofilter.java through the thickness of the
gel layer (y direction) by the method of lines; the shaken liquid above is
treated as well mixed (the COMSOL model uses D_mix = 1e-5 m2/s, which makes it
nearly uniform). Use it to check what COMSOL should give, and to see how much
diffusion through the gel slows uptake compared with the 0-D model.

    python comsol/preview_1d.py              # reads comsol/parameters_fitted.txt
    python comsol/preview_1d.py --f-gel 0.2  # stronger diffusion limitation
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp

HERE = Path(__file__).resolve().parent
UNIT = {"[1/d]": 1 / 86400, "[g/m^3]": 1.0, "[m^2/g]": 1.0}

M = dict(N=14.007, P=30.974, G=180.16, O2=31.998, X=24.6, NH4=18.038, PO4=94.971)


def load_params(path):
    p = {}
    for line in Path(path).read_text().splitlines():
        m = re.match(r"(\S+)\s+([-0-9.eE+]+)(\[[^\]]*\])?", line)
        if m:
            p[m.group(1)] = float(m.group(2)) * UNIT.get(m.group(3) or "", 1.0)
    return p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--params", default=HERE / "parameters_fitted.txt")
    ap.add_argument("--f-gel", type=float, default=0.6)
    ap.add_argument("--t-b", type=float, default=1e-3, help="gel thickness, m")
    ap.add_argument("--n", type=int, default=20, help="grid cells through the gel")
    ap.add_argument("--f-algae", type=float, default=0.5)
    ap.add_argument("--m-bio", type=float, default=0.1, help="g")
    a = ap.parse_args()
    k = load_params(a.params)

    W, L, VL = 0.04, 0.08, 50e-6                       # m, m, m3
    tb, n = a.t_b, a.n
    Vbf = W * L * tb
    dy = tb / n
    y = (np.arange(n) + 0.5) * dy                      # cell centres (0 = bottom)
    A = W * L                                          # interface area
    D = a.f_gel * np.array([1.96e-9, 0.76e-9, 0.67e-9, 2.1e-9])  # N, P, G, O2

    c0 = np.array([67.1 / M["NH4"], 29.9 / M["PO4"], 450 / M["G"], k["O_sat"] / M["O2"]])
    Xa0 = a.m_bio * a.f_algae / Vbf / M["X"]
    Xb0 = a.m_bio * (1 - a.f_algae) / Vbf / M["X"]
    PA0 = 0.01 * Xa0 * M["X"] / M["P"]
    # state: gel solutes (4 x n), biomass (5 x n), liquid solutes (4)
    y0 = np.concatenate([np.repeat(c0, n), np.repeat([Xa0, Xb0, PA0, 0, 0], n), c0])

    def rhs(t, s):
        c = np.maximum(s[:4 * n].reshape(4, n), 0)
        b = s[4 * n:9 * n].reshape(5, n)
        cl = np.maximum(s[9 * n:], 0)
        Xa, Xb, PA, SN, SP = np.maximum(b, 0)
        Xa_g, Xb_g = Xa * M["X"], Xb * M["X"]
        N_g, P_g, G_g, O_g = c[0] * M["N"], c[1] * M["P"], c[2] * M["G"], c[3] * M["O2"]
        Qp = np.maximum(PA * M["P"] / np.maximum(Xa_g, 1e-6), k["Q_min"] * 1.0001)
        photo = 0.5 * (1 + np.tanh(np.sin(2 * np.pi * t / 86400) / 0.05))
        I_loc = k["I0"] * np.exp(-k["K_a"] * Xa_g * (tb - y))
        f_I = photo * I_loc / (k["K_I"] + I_loc)
        mu_a = k["mu_max_a"] * f_I * N_g / (k["K_Na"] + N_g) * (1 - k["Q_min"] / Qp)
        rho_P = (k["rho_max_P"] * P_g / (k["K_P"] + P_g)
                 * np.maximum(k["Q_max"] - Qp, 0) / (k["Q_max"] - k["Q_min"]))
        mu_b = (k["mu_max_b"] * G_g / (k["K_G"] + G_g) * O_g / (k["K_O"] + O_g)
                * N_g / (k["K_Nb"] + N_g) * P_g / (k["K_Pb"] + P_g))
        g_a, g_b = mu_a * Xa_g, mu_b * Xb_g
        r_SN = k["k_s"] * (k["q_max_N"] * (Xa_g + Xb_g) * N_g / (k["K_s"] + N_g) - SN * M["N"])
        r_SP = k["k_s"] * (k["q_max_P"] * (Xa_g + Xb_g) * P_g / (k["K_s"] + P_g) - SP * M["P"])
        R = np.vstack([-(k["i_N_a"] * g_a + k["i_N_b"] * g_b + r_SN) / M["N"],
                       -(rho_P * Xa_g + k["i_P_b"] * g_b + r_SP) / M["P"],
                       -(g_b / k["Y_G"]) / M["G"],
                       (k["Y_O2_a"] * g_a - g_b * (1 - k["Y_G"]) / k["Y_G"] * 1.07) / M["O2"]])
        # diffusion: no flux at bottom, Dirichlet-like coupling to liquid at top (half cell)
        flux = np.zeros((4, n + 1))                           # upward flux at n+1 faces
        flux[:, 1:-1] = -D[:, None] * np.diff(c, axis=1) / dy
        flux[:, -1] = -D * (cl - c[:, -1]) / (dy / 2)         # top face, gel -> liquid
        dc = -np.diff(flux, axis=1) / dy + R
        dcl = flux[:, -1] * A / VL
        dcl[3] += k["kLa"] * (k["O_sat"] / M["O2"] - cl[3])
        db = np.vstack([(g_a - k["b_a"] * Xa_g) / M["X"], (g_b - k["b_b"] * Xb_g) / M["X"],
                        rho_P * Xa_g / M["P"] - k["b_a"] * PA, r_SN / M["N"], r_SP / M["P"]])
        return np.concatenate([dc.ravel(), db.ravel(), dcl])

    days = np.array([0, 1, 3, 5, 7])
    sol = solve_ivp(rhs, (0, 7 * 86400), y0, method="BDF", t_eval=days * 86400,
                    max_step=600, rtol=1e-5, atol=1e-10)
    cl = sol.y[9 * n:]
    print(f"f_gel = {a.f_gel}, gel thickness = {tb*1e3:g} mm, CV/BS algae fraction = {a.f_algae}")
    print(" day   NH4+ removal %   PO4 3- removal %   O2 liquid mg/L")
    for i, d in enumerate(days):
        print(f"{d:4d}   {100*(1-cl[0,i]/c0[0]):14.1f}   {100*(1-cl[1,i]/c0[1]):16.1f}"
              f"   {cl[3,i]*M['O2']:14.2f}")


if __name__ == "__main__":
    main()
