# COMSOL Multiphysics model of the living biofilter

A 2D model of one treatment bottle: 50 mL of synthetic wastewater above the 4 × 8 cm living biofilter, run for 7 days. Cells sit in a 1 mm gel layer. NH₄⁺, PO₄³⁻, glucose and O₂ diffuse into the gel and are taken up there. The kinetics are the same as the Python/R bioreactor model, so parameters fitted to your Fig. 3 data carry straight over.

| File | What it is |
|---|---|
| `LivingBiofilter.java` | Builds, solves and post-processes the model with the COMSOL Java API |
| `parameters_fitted.txt` | Kinetic parameters written by `python/run_bioreactor.py`; can also be loaded in the GUI |
| `preview_1d.py` | The same equations solved in 1D through the gel with SciPy, for checking without a licence |

> **Status.** `LivingBiofilter.java` compiles against stub COMSOL classes, so its Java is valid. It has not been run in COMSOL, because no licence was available when it was written. If COMSOL rejects a property name (these change between versions), build that step in the GUI with the guide below, then *File > Save As > Model File for Java* to see the exact name for your version.

## Option A: run the Java file (COMSOL 6.x)

```bash
cd comsol
comsolcompile LivingBiofilter.java
comsolbatch -inputfile LivingBiofilter.class -outputfile living_biofilter.mph
```

On Windows, both commands are in `C:\Program Files\COMSOL\COMSOL6x\Multiphysics\bin\win64\`. Open `living_biofilter.mph` in COMSOL Desktop. The run also writes `comsol_removal_vs_time.csv`.

## Option B: build it in the COMSOL Desktop

1. **New model:** 2D → Chemical Species Transport → *Transport of Diluted Species* (tds) → Time Dependent.
2. **Parameters:** Global Definitions → Parameters → *Load from File* → `parameters_fitted.txt`. Then add the geometry, initial-value and transport parameters listed at the top of `run()` in `LivingBiofilter.java` (W_t, L_t, t_b, H_L, m_bio, f_algae, C_NH4_0, molar masses, D values, and so on).
3. **Geometry:**
   - Rectangle r1 (biofilter): position (0, 0), size (W_t, t_b).
   - Rectangle r2 (liquid): position (0, t_b), size (W_t, H_L).
   - Tick *Resulting objects selectable* on both.
4. **Definitions:**
   - Average operator `aveop1` on the liquid.
   - Integration operator `intop1` on the biofilter.
   - Variables on the biofilter domain: copy the table `v` from the Java file (Xa_g, N_g, Qp, photo, I_loc, f_I, mu_a, rho_P, mu_b, g_a, g_b, r_SN, r_SP).
5. **tds (all domains):** species cN, cP, cG, cO.
   - Transport Properties: D_mix for all four species.
   - Second Transport Properties on the biofilter: f_gel·D_NH4, f_gel·D_PO4, f_gel·D_G, f_gel·D_O2.
   - Reactions on the biofilter: R_cN, R_cP, R_cG, R_cO, written as in the Java file.
   - Reactions on the liquid: R_cO = kLa·(O_sat/M_O2 − cO).
   - Initial values: cN0, cP0, cG0, cO0.
6. **Second tds (biofilter only):** species Xa, Xb, PA, SN, SP.
   - Diffusivity D_cell, which is effectively zero.
   - Reactions R_Xa, R_Xb, R_PA, R_SN, R_SP.
   - Initial values Xa0, Xb0, PA0, 0, 0.
7. **Mesh:** Free Triangular, with a Size node on the biofilter (maximum element size t_b/6).
8. **Study:** Time Dependent, unit d, times `range(0,1/24,7)`.
9. **Results:** Global plot of `100*(1-aveop1(cN)/cN0)` and `100*(1-aveop1(cP)/cP0)` against time. Compare it with Fig. 3a,b.

## Things to try

- **Mixing ratio:** set `f_algae` to 0.75 for CV/BS 3:1 and `m_bio = 0.13[g]` (the initial biomass for that trial).
- **Gel thickness:** change `t_b`, or `f_gel` for a denser gel. Diffusion becomes limiting when the gel is thick or dense. Preview this with `python comsol/preview_1d.py --f-gel 0.05`.
- **Scale-up:** change `V_L`, `W_t` and `L_t` to model a larger tank with several biofilter sheets.
- **Flow:** replace `D_mix` with a *Laminar Flow* interface to resolve the shaker flow (much more expensive).

## Assumptions

- **Mixing:** the shaken liquid is treated as well mixed through a large effective diffusivity (D_mix). Flow is not solved.
- **Light:** light enters from above and is attenuated by Beer–Lambert inside the gel, using the local algal density. The 12:12 h cycle is smoothed with tanh so the solver can take reasonable steps.
- **Gel thickness:** the 1 mm thickness and f_gel = 0.6 are assumptions, not measured values. Measure them if diffusion matters for your question.
- **Fitted parameters:** values in `parameters_fitted.txt` were fitted with the 0-D model. In 2D the extra diffusion resistance lowers early uptake slightly (see `preview_1d.py`), so refit inside COMSOL (Optimization module) if you need an exact match.
